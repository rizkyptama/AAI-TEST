Langkah - Langkah Running Aplikasi :
1. Unduh composer installer di https://getcomposer.org/
2. Install composer
3. Buka cmd dan arahkan pada direktori aai, contoh : 'cd C:/xampp/htdocs/aai'
4. Ketikan 'php artisan serve'
5. Akan keluar link localhost untuk membuka aplikasi
6. Buka browser dan ketikkan link localhost yang ada pada point ke-5 