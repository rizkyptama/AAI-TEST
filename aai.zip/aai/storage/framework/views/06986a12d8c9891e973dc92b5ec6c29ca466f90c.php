<!DOCTYPE html>
<html>
    <?php $__env->startSection('head'); ?>
        <?php echo $__env->make('template.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  	<body>
		<?php $__env->startSection('sidebar'); ?>
		    <?php echo $__env->make('template.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		    <div class="main-content" id="panel">
			<?php $__env->startSection('header'); ?>
			    <?php echo $__env->make('template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				<div class="container-fluid mt--6">
				<?php echo $__env->yieldSection(); ?>
					<?php echo $__env->yieldContent('content'); ?>

				<?php $__env->startSection('footer'); ?>
				    <?php echo $__env->make('template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
		</div>
	</body>
	<?php $__env->startSection('mainjs'); ?>
	    <?php echo $__env->make('template.mainjs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</html>