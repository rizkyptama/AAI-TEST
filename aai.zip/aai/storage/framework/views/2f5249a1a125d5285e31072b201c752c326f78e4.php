<?php $__env->startSection('content'); ?>	

<div class="row" onload="people()">
	<div class="col-xl-12">
		<div class="card">
			<div class="card-header border-0">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0" id="title"></h3>
					</div>
				</div>
			</div>
			<div class="table-responsive">
				<!-- Projects table -->
				<table class="table table-bordered align-items-center table-striped table-hover table-flush text-center datatables-print" id="people">
					<thead class="thead-light">
						<tr>
							<th>No</th>
							<th>Name</th>
							<th>Known For</th>
							<th>Popularity</th>
						</tr>
					</thead>
					<tbody class="list">

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>