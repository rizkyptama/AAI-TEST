<?php $__env->startSection('content'); ?>	

<div class="row">
	<div class="col-xl-6 col-6 col-md-6">
        <div class="card card-stats">
          	<div class="card-body">
            	<div class="row">
              		<div class="col">
		                <select class="form-control" id="Kelas" style="width:100%;" name="ddlKelas" onchange="filterKehadiran()">
		                	<option value="0" hidden="">Pilih Kelas</option>
		                	<?php foreach($kelas as $res): ?> 
		                	<option value="<?php echo e($res->id_kelas); ?>"><?php echo e($res->tingkat_kelas); ?> <?php echo e($res->kelas); ?></option>
		                	<?php endforeach; ?>
		                </select>
             		</div>
             		<div class="col-auto">
               			<div class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow">
                        	<i class="ni ni-shop"></i>
                      	</div>
                    </div>
            	</div>
         	</div>
     	</div>
  	</div>
  	<div class="col-xl-6 col-6 col-md-6">
    	<div class="card card-stats">
        	<div class="card-body">
           		<div class="row">
             		<div class="col">
                      	<select class="form-control" id="Mapel" style="width:100%;" name="ddlMapel" onchange="filterKehadiran()">
		                	<option value="0" hidden="">Pilih Mata Pelajaran</option>
		                	<?php foreach($mapel as $res): ?> 
		                	<option value="<?php echo e($res->id_gurumapel); ?>"><?php echo e($res->mapel); ?></option>
		                	<?php endforeach; ?>
		                </select>
                    </div>
                    <div class="col-auto">
                    	<div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow">
                        	<i class="ni ni-books"></i>
                      	</div>
                    </div>
             	</div>
         	</div>
      	</div>
  	</div>
</div>

<div class="row">
	<div class="col-xl-12">
		<div class="card">
			<div class="card-header border-0">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0">Halaman Kehadiran Siswa</h3>
					</div>
					<div class="col text-right">
						<a href="#" class="btn btn-sm btn-primary" onclick="addKehadiran()"><i class="fas fa-plus text-white mr-1"></i> Kehadiran Siswa</a>
					</div>
				</div>
			</div>
			<div class="table-responsive">
				<!-- Projects table -->
				<table class="table table-bordered align-items-center table-striped table-hover table-flush text-center datatables-print" id="tblKehadiran">
					<thead class="thead-light">
						<tr>
							<th>No</th>
							<th>Tanggal</th>
							<th>Kelas</th>
							<th>Mapel</th>
							<!-- <th>Kehadiran</th> -->
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody class="list">
						<!-- <?php $no = 1; ?>
						<?php foreach($kehadiran as $row): ?>
						<tr>
							<th><?php echo e($no++); ?></th>
							<td><?php echo e($row->tanggal_absen); ?></td>
							<td><?php echo e($row->tingkat_kelas); ?> <?php echo e($row->kelas); ?></td>
							<td><?php echo e($row->mapel); ?></td>
							<td>
								<button class="btn btn-warning btn-sm" type="button" onclick="editabsen('<?php echo e($row->kd_absen); ?>')" title="Ubah Data"><i class="fa fa-edit"></i></button>
								<button class="btn btn-danger btn-sm" type="button" onclick="deleteabsen('<?php echo e($row->kd_absen); ?>')" title="Hapus Data"><i class="fa fa-trash"></i></button>
							</td>
						</tr>
						<?php endforeach; ?> -->
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<!-- The Modal Update-->
<div class="modal modal-secondary fade bd-example-modal-lg" id="ModalEditAbsen">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">

		<form method="post" id="updatesiswa">
    	<!-- Modal Header -->
	  	<div class="modal-header">
	    	<h4 class="modal-title">Absen Kehadiran Siswa (<span id="kelas"></span> - <span id="mapel"></span>)</h4>
	    	<button type="button" class="close" data-dismiss="modal">&times;</button>
	  	</div>

    	<!-- Modal body -->
      	<div class="modal-body">
		  	<div class="row">
		     	<input type="text" name="kd_absen" id="kd_absen" hidden="">
		     	<input type="text" name="id_kelas" id="id_kelas" hidden="">
		     	<input type="text" name="id_tenagapendidik" id="eid_tenagapendidik" value="1" hidden="">
		      	<input type="text" name="_token" value="<?php echo e(csrf_token()); ?>" hidden="">
			  	<div class="col-lg-10 col-sm-6">
			      	<div class="form-group">
			        	<label>Tanggal</label>
			            <input type="date" name="tanggal" value="<?php echo date('Y-m-d'); ?>" class="form-control" required="" id="etanggalAbsen" required>
			     	</div>
			 	</div>
			  	<!-- <div class="col-lg-4">
			       	<div class="form-group">
			       		<label>Kelas</label>
			            <select class="form-control" id="eddlAbsenKelas" style="width:100%;" name="ddlAbsenKelas" onchange="tambahsiswa()" required="" disabled="">
		                	<option value="" hidden="">Pilih Kelas</option>
		                	<?php foreach($kelas as $res): ?> 
		                	<option value="<?php echo e($res->id_kelas); ?>"><?php echo e($res->tingkat_kelas); ?> <?php echo e($res->kelas); ?></option>
		                	<?php endforeach; ?>
		                </select>
			      	</div>
			   	</div> -->
			  	<!-- <div class="col-lg-5">
			      	<div class="form-group">
			        	<label>Mata Pelajaran</label>
			            <select class="form-control" id="eddlAbsenMapel" style="width:100%;" name="ddlAbsenMapel" required="">
		                	<option value="" hidden="">Pilih Mapel</option>
		                	<?php foreach($mapel as $res): ?> 
		                	<option value="<?php echo e($res->id_gurumapel); ?>"><?php echo e($res->mapel); ?></option>
		                	<?php endforeach; ?>
		                </select>
			        </div>
			    </div> -->
			    <div class="col-lg-2 col-sm-6">
			      	<div class="form-group">
			      		<label>&nbsp;</label>
	       				<input type="submit" name="save" id="save" class="btn btn-primary form-control" value="Update" />
			        </div>
			    </div>
			    <div class="row">
			        <div class="col-lg-12">
			        	<div class="table-responsive">
							<table class="table align-items-center table-flush">
								<thead class="thead-light">
									<tr>
										<th scope="col">
											<label class="btn bg-success"></label> : Masuk
										</th>
										<th scope="col">
											<label class="btn bg-info"></label> : Izin
										</th>
										<th scope="col">
											<label class="btn bg-warning"></label> : Sakit
										</th>
										<th scope="col">
											<label class="btn bg-danger"></label> : Alfa
										</th>
									</tr>
								</thead>
							</table>
						</div>
			        </div>
			        <div class="col-lg-12">
			          <div class="form-group mb-0 text-center">
			            <label class="form-control-label d-block mb-3">Absen Siswa</label>
			            	<div class="table-responsive" style="overflow-y: auto; max-height: 280px">
								<!-- Projects table -->
								<table class="table align-items-center table-flush" id="elistsiswa">
									<thead class="thead-light">
										<tr>
											<th>No</th>
											<th>Nama Siswa</th>
											<th>Keterangan</th>
										</tr>
									</thead>
									<tbody>
									</tbody>
								</table>
							</div>
			            </div>
			    	</div>
	        	</div>
	      	</div>
	   	</div>

     	<!-- Modal footer -->
		<!--<div class="modal-footer">
	      	<button type="button" class="btn btn-lin mr-auto" data-dismiss="modal">Tutup</button>
	       	<button type="button" class="btn btn-info" onclick="tambahKehadiran()">Simpan</button>
	       	<input type="submit" name="save" id="save" class="btn btn-primary" value="Update" />
	  	</div> -->
	  	</form>

    </div>
  </div>
</div>

<!-- The Modal Tambah-->
<div class="modal modal-secondary fade bd-example-modal-lg" id="ModalTambahAbsen">
  	<div class="modal-dialog modal-dialog-centered modal-lg">
    	<div class="modal-content">

			<form method="post" id="tambahsiswa">
	    	<!-- Modal Header -->
	    	<div class="modal-header">
	      		<h4 class="modal-title">Absen Kehadiran Siswa</h4>
	      		<button type="button" class="close" data-dismiss="modal">&times;</button>
	    	</div>

		    <!-- Modal body -->
		    <div class="modal-body">
		      	<div class="row">
		      		<input type="text" name="id_tenagapendidik" value="1" hidden="">
		      		<input type="text" name="_token" value="<?php echo e(csrf_token()); ?>" hidden="">
		      		<input type="text" id="inputkelas" name="inputkelas" hidden="">
		      		<input type="text" id="inputmapel" name="inputmapel" hidden="">
			        <div class="col-lg-4">
			          <div class="form-group">
			            <label>Tanggal</label>
			            <input type="date" name="tanggal" value="<?php echo date('Y-m-d'); ?>" class="form-control" required="" id="tanggalAbsen" required>
			          </div>
			        </div>
			        <div class="col-lg-4">
			          <div class="form-group">
			            <label>Kelas</label>
			            <select class="form-control" id="ddlAbsenKelas" style="width:100%;" name="ddlAbsenKelas" onchange="tambahsiswa()" disabled="">
		                	<option value="" hidden="">Pilih Kelas</option>
		                	<?php foreach($kelas as $res): ?> 
		                	<option value="<?php echo e($res->id_kelas); ?>"><?php echo e($res->tingkat_kelas); ?> <?php echo e($res->kelas); ?></option>
		                	<?php endforeach; ?>
		                </select>
			          </div>
			        </div>
			        <div class="col-lg-4">
			          <div class="form-group">
			            <label>Mata Pelajaran</label>
			            <select class="form-control" id="ddlAbsenMapel" style="width:100%;" name="ddlAbsenMapel" disabled="">
		                	<option value="" hidden="">Pilih Mapel</option>
		                	<?php foreach($mapel as $res): ?> 
		                	<option value="<?php echo e($res->id_gurumapel); ?>"><?php echo e($res->mapel); ?></option>
		                	<?php endforeach; ?>
		                </select>
			        </div>
			    </div>
			        <!-- <div class="col-lg-12">
			          <div class="form-group">
			            <label>Kegiatan</label>
			            <input type="text" name="kegiatan" class="form-control" placeholder="Masukan Kegiatan Disini" required="">
			          </div>
			        </div> -->
			    <div class="row">
			        <div class="col-lg-12">
			        	<div class="table-responsive">
							<table class="table align-items-center table-flush">
								<thead class="thead-light">
									<tr>
										<th scope="col">
											<label class="btn bg-success"></label> : Masuk
										</th>
										<th scope="col">
											<label class="btn bg-info"></label> : Izin
										</th>
										<th scope="col">
											<label class="btn bg-warning"></label> : Sakit
										</th>
										<th scope="col">
											<label class="btn bg-danger"></label> : Alfa
										</th>
									</tr>
								</thead>
							</table>
						</div>
			        </div>
			        <div class="col-lg-12">
			          <div class="form-group mb-0 text-center">
			            <label class="form-control-label d-block mb-3">Absen Siswa</label>
			            	<div class="table-responsive" style="overflow-y: auto; max-height: 280px">
								<!-- Projects table -->
								<table class="table align-items-center table-flush" id="listsiswa">
									<thead class="thead-light">
										<tr>
											<th>No</th>
											<th>Nama Siswa</th>
											<th>Keterangan</th>
										</tr>
									</thead>
									<tbody>
										<!-- <?php $no = 1; ?>
										<?php foreach($siswa as $siswa): ?>
										<tr>
											<td><?php echo e($no++); ?></td>
											<td><label id="nama_siswa"><?php echo e($siswa->nama_lengkap); ?></label></td>
											<td>
							                    <div class="btn-group btn-group-toggle btn-group-colors event-tag" data-toggle="buttons">
							                      <label class="btn bg-success"><input type="radio" name="status" value="masuk" autocomplete="off"></label>
							                      &nbsp;
							                      <label class="btn bg-info"><input type="radio" name="status" value="izin" autocomplete="off"></label>
							                      &nbsp;
							                      <label class="btn bg-warning"><input type="radio" name="status" value="sakit" autocomplete="off"></label>
							                      &nbsp;
							                      <label class="btn bg-danger"><input type="radio" name="status" value="alfa" autocomplete="off"></label>
							                    </div>
											</td>
										</tr>
										<?php endforeach; ?> -->
									</tbody>
								</table>
							</div>
			            </div>
			    	</div>
	        	</div>
	      	</div>

	      	<!-- Modal footer -->
	      	<div class="modal-footer">
	        	<button type="button" class="btn btn-lin mr-auto" data-dismiss="modal">Tutup</button>
	        	<!-- <button type="button" class="btn btn-info" onclick="tambahKehadiran()">Simpan</button> -->
	        	<input type="submit" name="save" id="save" class="btn btn-primary" value="Simpan" />
	      	</div>
	        </form>
    	</div>
  	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>