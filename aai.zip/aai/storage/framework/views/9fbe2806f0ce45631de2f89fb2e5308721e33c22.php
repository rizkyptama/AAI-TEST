<?php $__env->startSection('content'); ?>	

<div class="row">
	<div class="col-xl-6 col-6 col-md-6">
        <div class="card card-stats">
          	<div class="card-body">
            	<div class="row">
              		<div class="col">
		                <select class="form-control" id="Kelas" style="width:100%;" name="ddlKelas" onchange="filterPengetahuan()">
		                	<option value="0" hidden="">Pilih Kelas</option>
		                	<?php foreach($kelas as $res): ?> 
		                	<option value="<?php echo e($res->id_kelas); ?>"><?php echo e($res->tingkat_kelas); ?> <?php echo e($res->kelas); ?></option>
		                	<?php endforeach; ?>
		                </select>
             		</div>
             		<div class="col-auto">
               			<div class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow">
                        	<i class="ni ni-shop"></i>
                      	</div>
                    </div>
            	</div>
         	</div>
     	</div>
  	</div>
  	<div class="col-xl-6 col-6 col-md-6">
    	<div class="card card-stats">
        	<div class="card-body">
           		<div class="row">
             		<div class="col">
                      	<select class="form-control" id="Mapel" style="width:100%;" name="ddlMapel" onchange="filterPengetahuan()">
		                	<option value="0" hidden="">Pilih Mata Pelajaran</option>
		                	<?php foreach($mapel as $res): ?> 
		                	<option value="<?php echo e($res->id_gurumapel); ?>"><?php echo e($res->mapel); ?></option>
		                	<?php endforeach; ?>
		                </select>
                    </div>
                    <div class="col-auto">
                    	<div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow">
                        	<i class="ni ni-books"></i>
                      	</div>
                    </div>
             	</div>
         	</div>
      	</div>
  	</div>
</div>

<div class="row">
	<div class="col-xl-12">
		<div class="card">
			<div class="card-header border-0">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0">Halaman Penilaian Pengetahuan</h3>
					</div>
					<div class="col text-right">
						<a href="#" class="btn btn-sm btn-primary" onclick="addPengetahuan()"><i class="fas fa-plus text-white mr-1"></i> Penilaian</a>
					</div>
				</div>
			</div>
			<div class="table-responsive">
				<!-- Projects table -->
				<table class="table table-bordered align-items-center table-striped table-hover table-flush text-center datatables-print" id="tblPengetahuan">
					<thead class="thead-light">
						<tr>
							<th>No</th>
							<th>Mata Pelajaran</th>
							<th>Kelas</th>
							<th>Tahun Ajaran</th>
							<th>Semester</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody class="list">
						<!-- <?php $no = 1; ?>
						<?php foreach($pengetahuan as $row): ?>
						<tr>
							<th><?php echo e($no++); ?></th>
							<td><?php echo e($row->mapel); ?></td>
							<td><?php echo e($row->tingkat_kelas); ?> <?php echo e($row->kelas); ?></td>
							<td><?php echo e($row->tahun_ajaran); ?></td>
							<td>
								<button class="btn btn-warning btn-sm" type="button" onclick="editPengetahuan('<?php echo e($row->kd_pengetahuan); ?>')" title="Ubah Data"><i class="fa fa-edit"></i></button>
								<button class="btn btn-danger btn-sm" type="button" onclick="deletePengetahuan('<?php echo e($row->kd_pengetahuan); ?>')" title="Hapus Data"><i class="fa fa-trash"></i></button>
							</td>
						</tr>
						<?php endforeach; ?> -->
					</tbody>
				</table>
			</div>
			<iframe id="txtArea1" style="display:none"></iframe>
			<div style="display:none;">
				<table class="table table-bordered align-items-center table-striped table-hover table-flush text-center datatables-print" id="tblExpPeng">
					<thead class="thead-light">
						<tr>
							<th rowspan="2" style="min-width: 50px">NO</th>
							<th rowspan="2" style="min-width: 200px">NAMA PESERTA DIDIK</th>
							<th colspan="5">KD <span id="ekd1"></span></th>
							<th colspan="5">KD <span id="ekd2"></span></th>
							<th colspan="5">KD <span id="ekd3"></span></th>
							<th colspan="5">KD <span id="ekd4"></span></th>
							<th colspan="5">KD <span id="ekd5"></span></th>
							<th rowspan="2" class="title">RERATA NH</th>
							<th rowspan="2" class="title">PTS</th>
							<th rowspan="2" class="title">PAS/PAT</th>
							<th rowspan="2" class="title">NILAI AKHIR</th>
							<th rowspan="2" class="title">KETERANGAN</th>
						</tr>
						<tr>
							<th class="title">TES TULIS</th>
							<th class="title">TUGAS</th>
							<th class="title">LAINNYA</th>
							<th class="title">RERATA</th>
							<th class="title">NH1</th>

							<th class="title">TES TULIS</th>
							<th class="title">TUGAS</th>
							<th class="title">LAINNYA</th>
							<th class="title">RERATA</th>
							<th class="title">NH2</th>

							<th class="title">TES TULIS</th>
							<th class="title">TUGAS</th>
							<th class="title">LAINNYA</th>
							<th class="title">RERATA</th>
							<th class="title">NH3</th>

							<th class="title">TES TULIS</th>
							<th class="title">TUGAS</th>
							<th class="title">LAINNYA</th>
							<th class="title">RERATA</th>
							<th class="title">NH4</th>

							<th class="title">TES TULIS</th>
							<th class="title">TUGAS</th>
							<th class="title">LAINNYA</th>
							<th class="title">RERATA</th>
							<th class="title">NH5</th>
						</tr>
					</thead>
					<tbody></tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<!-- The Modal Update-->
<div class="modal modal-secondary fade " id="ModalEditPengetahuan">
  	<div class="modal-dialog modal-dialog-centered" style="min-width: 98%;">
    	<div class="modal-content">

			<form method="post" id="updatePengetahuan">
	    	<!-- Modal Header -->
	    	<div class="modal-header">
	      		<h4 class="modal-title">Penilaian Kompetensi Pengetahuan (<span id="kelas"></span> - <span id="mapel"></span>)</h4>
	      		<button type="button" class="close" data-dismiss="modal">&times;</button>
	    	</div>

		    <!-- Modal body -->
		    <div class="modal-body">
		      	<div class="row">
			     	<input type="text" name="kd_pengetahuan" id="kd_pengetahuan" hidden="">
		      		<input type="text" name="_token" value="<?php echo e(csrf_token()); ?>" hidden="">
			        <div class="col-lg-4">
			          	<div class="form-group">
			            	<label>Tanggal</label>
			            	<input type="date" name="tanggal" class="form-control" required="" id="etanggal" required>
			          	</div>
			        </div>
			        <!-- <div class="col-lg-3">
			          	<div class="form-group">
				            <label>Kelas</label>
				            <select class="form-control" id="eddlKelas" style="width:100%;" name="ddlKelas" onchange="listPengetahuan()" required="">
			                	<option value="" hidden="">Pilih Kelas</option>
			                	<?php foreach($kelas as $res): ?> 
			                	<option value="<?php echo e($res->id_kelas); ?>"><?php echo e($res->tingkat_kelas); ?> <?php echo e($res->kelas); ?></option>
			                	<?php endforeach; ?>
			                </select>
			          	</div>
			        </div>
			        <div class="col-lg-3">
			          	<div class="form-group">
				            <label>Mata Pelajaran</label>
				            <select class="form-control" id="ddlMapel" style="width:100%;" name="ddlMapel" required="">
			                	<option value="" hidden="">Pilih Mapel</option>
			                	<?php foreach($mapel as $res): ?> 
			                	<option value="<?php echo e($res->id_gurumapel); ?>"><?php echo e($res->mapel); ?></option>
			                	<?php endforeach; ?>
			                </select>
		            	</div>
			        </div> -->
			        <div class="col-lg-4">
			          	<div class="form-group">
				            <label>Tahun Ajaran</label>
				            <select class="form-control" id="eddlTahunAjaran" style="width:100%;" name="ddlTahunAjaran">
			                	<option value="" hidden="">Pilih Tahun Ajaran</option>
			                	<?php foreach($tahun_ajaran as $res): ?> 
			                	<option value="<?php echo e($res->tahun_ajaran); ?>"><?php echo e($res->tahun_ajaran); ?></option>
			                	<?php endforeach; ?>
			                </select>
			          	</div>
			        </div>
			        <div class="col-lg-4">
			          	<div class="form-group">
				            <label>Semester</label>
				            <select class="form-control" id="eddlSemester" style="width:100%;" name="ddlSemester">
			                	<option value="" hidden="">Pilih Semester</option>
			                	<option value="1">1</option>
			                	<option value="2">2</option>
			                </select>
			          	</div>
			        </div>
			    </div>
			    <div class="row">
			        <div class="col-lg-12">
			          <div class="form-group mb-0 text-center">
			            <label class="form-control-label d-block mb-3">KOMPETENSI PENGETAHUAN</label>
			            	<div class="table-responsive" style="overflow: auto; height: 325px; max-height: 500px">
								<!-- Projects table -->
								<table class="table table-sm table-condensed table-hover align-items-center table-bordered" id="elistsiswa">
									<thead class="thead-light">
										<tr>
											<th rowspan="2" style="min-width: 50px">NO</th>
											<th rowspan="2" style="min-width: 200px">NAMA PESERTA DIDIK</th>
											<th colspan="5">KD <input type="text" name="kd1" class="form-control kd" id="kd1"></th>
											<th colspan="5">KD <input type="text" name="kd2" class="form-control kd" id="kd2"></th>
											<th colspan="5">KD <input type="text" name="kd3" class="form-control kd" id="kd3"></th>
											<th colspan="5">KD <input type="text" name="kd4" class="form-control kd" id="kd4"></th>
											<th colspan="5">KD <input type="text" name="kd5" class="form-control kd" id="kd5"></th>
											<th rowspan="2" class="title">RERATA NH</th>
											<th rowspan="2" class="title">PTS</th>
											<th rowspan="2" class="title">PAS/PAT</th>
											<th rowspan="2" class="title">NILAI AKHIR</th>
											<th rowspan="2" class="title">KETERANGAN</th>
										</tr>
										<tr>
											<th class="title">TES TULIS</th>
											<th class="title">TUGAS</th>
											<th class="title">LAINNYA</th>
											<th class="title">RERATA</th>
											<th class="title">NH1</th>

											<th class="title">TES TULIS</th>
											<th class="title">TUGAS</th>
											<th class="title">LAINNYA</th>
											<th class="title">RERATA</th>
											<th class="title">NH2</th>

											<th class="title">TES TULIS</th>
											<th class="title">TUGAS</th>
											<th class="title">LAINNYA</th>
											<th class="title">RERATA</th>
											<th class="title">NH3</th>

											<th class="title">TES TULIS</th>
											<th class="title">TUGAS</th>
											<th class="title">LAINNYA</th>
											<th class="title">RERATA</th>
											<th class="title">NH4</th>

											<th class="title">TES TULIS</th>
											<th class="title">TUGAS</th>
											<th class="title">LAINNYA</th>
											<th class="title">RERATA</th>
											<th class="title">NH5</th>
										</tr>
									</thead>
									<tbody>

									</tbody>
								</table>
							</div>
			            </div>
			    	</div>
	        	</div>
	      	</div>

	      	<!-- Modal footer -->
	      	<div class="modal-footer">
	        	<button type="button" class="btn btn-lin mr-auto" data-dismiss="modal">Tutup</button>
	        	<!-- <button type="button" class="btn btn-info" onclick="tambahKehadiran()">Simpan</button> -->
	        	<input type="submit" name="save" id="save" class="btn btn-primary" value="Update" />
	      	</div>
	        </form>
    	</div>
  	</div>
</div>

<!-- The Modal Tambah-->
<div class="modal modal-secondary fade " id="ModalTambahPengetahuan">
  	<div class="modal-dialog modal-dialog-centered" style="min-width: 98%;">
    	<div class="modal-content">

			<form method="post" id="tambahPengetahuan">
	    	<!-- Modal Header -->
	    	<div class="modal-header">
	      		<h4 class="modal-title">Penilaian Kompetensi Pengetahuan</h4>
	      		<button type="button" class="close" data-dismiss="modal">&times;</button>
	    	</div>

		    <!-- Modal body -->
		    <div class="modal-body">
		      	<div class="row">
		      		<input type="text" name="id_tenagapendidik" value="1" hidden="">
		      		<input type="text" name="_token" value="<?php echo e(csrf_token()); ?>" hidden="">
		      		<input type="text" id="inputkelas" name="inputkelas" hidden="">
		      		<input type="text" id="inputmapel" name="inputmapel" hidden="">
			        <div class="col-lg-2">
			          	<div class="form-group">
			            	<label>Tanggal</label>
			            	<input type="date" name="tanggal" value="<?php echo date('Y-m-d'); ?>" class="form-control" required="" id="tanggal" required>
			          	</div>
			        </div>
			        <div class="col-lg-2">
			          	<div class="form-group">
				            <label>Kelas</label>
				            <select class="form-control" id="ddlKelas" style="width:100%;" name="ddlKelas" onchange="listPengetahuan()" disabled="">
			                	<option value="" hidden="">Pilih Kelas</option>
			                	<?php foreach($kelas as $res): ?> 
			                	<option value="<?php echo e($res->id_kelas); ?>"><?php echo e($res->tingkat_kelas); ?> <?php echo e($res->kelas); ?></option>
			                	<?php endforeach; ?>
			                </select>
			          	</div>
			        </div>
			        <div class="col-lg-2">
			          	<div class="form-group">
				            <label>Mata Pelajaran</label>
				            <select class="form-control" id="ddlMapel" style="width:100%;" name="ddlMapel" disabled="">
			                	<option value="" hidden="">Pilih Mapel</option>
			                	<?php foreach($mapel as $res): ?> 
			                	<option value="<?php echo e($res->id_gurumapel); ?>"><?php echo e($res->mapel); ?></option>
			                	<?php endforeach; ?>
			                </select>
		            	</div>
			        </div>
			        <div class="col-lg-2">
			          	<div class="form-group">
				            <label>Tahun Ajaran</label>
				            <select class="form-control" id="ddlTahunAjaran" style="width:100%;" name="ddlTahunAjaran">
			                	<option value="" hidden="">Pilih Tahun Ajaran</option>
			                	<?php foreach($tahun_ajaran as $res): ?> 
			                	<option value="<?php echo e($res->tahun_ajaran); ?>"><?php echo e($res->tahun_ajaran); ?></option>
			                	<?php endforeach; ?>
			                </select>
			          	</div>
			        </div>
			        <div class="col-lg-2">
			          	<div class="form-group">
				            <label>Semester</label>
				            <select class="form-control" id="ddlSemester" style="width:100%;" name="ddlSemester">
			                	<option value="" hidden="">Pilih Semester</option>
			                	<option value="1">1</option>
			                	<option value="2">2</option>
			                </select>
			          	</div>
			        </div>
			        <div class="col-lg-2">
			          	<div class="form-group">
				            <label>Jenis Penilaian</label>
				            <select class="form-control" id="ddlPenilaian" style="width:100%;" name="ddlPenilaian" onchange="changepengetahuan()">
			                	<option value="" hidden="">Pilih Penilaian</option>
			                	<option value="1">KD 1</option>
			                	<option value="2">KD 2</option>
			                	<option value="3">KD 3</option>
			                	<option value="4">KD 4</option>
			                	<option value="5">KD 5</option>
			                	<option value="6">RERATA NH</option>
			                	<option value="7">PTS</option>
			                	<option value="8">PAS/PAT</option>
			                	<option value="9">NILAI AKHIR</option>
			                	<option value="10">KETERANGAN</option>
			                </select>
			          	</div>
			        </div>
			    </div>
			    <div class="row">
			        <div class="col-lg-12">
			          <div class="form-group mb-0 text-center">
			            <label class="form-control-label d-block mb-3">KOMPETENSI PENGETAHUAN</label>
			            	<div class="table-responsive" style="overflow: auto; height: 325px; max-height: 500px">
								<!-- Projects table -->
								<table class="table table-sm table-condensed table-hover align-items-center table-bordered" id="listsiswa">
								</table>
							</div>
			            </div>
			    	</div>
	        	</div>
	      	</div>

	      	<!-- Modal footer -->
	      	<div class="modal-footer">
	        	<button type="button" class="btn btn-lin mr-auto" data-dismiss="modal">Tutup</button>
	        	<!-- <button type="button" class="btn btn-info" onclick="tambahKehadiran()">Simpan</button> -->
	        	<input type="submit" name="save" id="save" class="btn btn-primary" value="Simpan" />
	      	</div>
	        </form>
    	</div>
  	</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>