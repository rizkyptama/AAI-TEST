  <!-- Core -->
  <script src="<?php echo e(asset('vendor/jquery/dist/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/js-cookie/js.cookie.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')); ?>"></script>
  <!-- Optional JS -->
  <script src="<?php echo e(asset('vendor/chart.js/dist/Chart.min.js')); ?>"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  <script src="<?php echo e(asset('vendor/chart.js/dist/Chart.extension.js')); ?>"></script>
  <!-- Argon JS -->
  <script src="<?php echo e(asset('js/argon.min9f1e.js?v=1.1.0')); ?>"></script>
  <!-- Demo JS - remove this in your project -->
  <script src="<?php echo e(asset('js/demo.min.js')); ?>"></script>
  <!-- <script src="https://code.jquery.com/jquery-3.1.0.js"></script> -->
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.0/js/dataTables.buttons.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.0/js/buttons.flash.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.0/js/buttons.html5.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.6.0/js/buttons.print.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/js/select2.min.js"></script>
  <script type="text/javascript">
    $(document).ready( function () {
      $('#tblKehadiran').DataTable({
        dom: 'Bfrtip',
        buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
        ]
      });
      $('#tblJurnal').DataTable({
        dom: 'Bfrtip',
        buttons: [
        'copy', 'csv', 'excel', 'pdf', 'print'
        ]
      });
    });

    function logout(){
      swal({
        title: "Apa Anda Ingin Keluar?",
        text: "Jika anda keluar maka anda harus login lagi terlebih dahulu!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
          window.location.href = '<?php echo e(url("actionLogout")); ?>';
        } else {
        }
      });
    } 

    function filterJurnal(){
      var id_kelas = $("#Kelas").val();
      var id_gurumapel = $("#Mapel").val();
      $('#tblJurnal tbody tr').remove();
      $.ajax({
        type: 'POST',
        url: '<?php echo e(url("getJurnal")); ?>',
        data: {
          'id_kelas': id_kelas,
          'id_gurumapel': id_gurumapel,
          "_token" : "<?php echo e(csrf_token()); ?>"
        },
        dataType: 'json',
        success: function (data) {
          if (data != 'fail') {
            console.log(data);
            var tbl = '';
            for (var i = 0; i < data.length; i++) {
              var no = i + 1;
              tbl += '<tr>';
              tbl += '<td>' + no + '</td>';
              tbl += '<td>' + data[i].tanggal + '</td>';
              tbl += '<td>' + data[i].mapel + '</td>';
              tbl += '<td>' + data[i].materi + '</td>';
              tbl += '<td>' + data[i].tahun_ajaran + '</td>';
              tbl += '<td><button class="btn btn-warning btn-sm" type="button" onclick="editJurnal('+data[i].id_jurnal+')" title="Ubah Data"><i class="fa fa-edit"></i></button><button class="btn btn-danger btn-sm" type="button" onclick="deleteJurnal('+data[i].id_jurnal+')" title="Hapus Data"><i class="fa fa-trash"></i></button></td>';
              tbl += '</tr>';
            }
            $('#tblJurnal tbody').append(tbl);
          } else {
            var tbl = '<tr><td colspan="6">NO DATA AVAILABLE IN TABLE</td></tr>';
            $('#tblJurnal tbody').append(tbl);
          }
        }
      });
    }

    function filterKehadiran(){
      var id_kelas = $("#Kelas").val();
      var id_gurumapel = $("#Mapel").val();
      $('#tblKehadiran tbody tr').remove();
      $.ajax({
        type: 'POST',
        url: '<?php echo e(url("getKehadiran")); ?>',
        data: {
          'id_kelas': id_kelas,
          'id_gurumapel': id_gurumapel,
          "_token" : "<?php echo e(csrf_token()); ?>"
        },
        dataType: 'json',
        success: function (data) {
          if (data != 'fail') {
            console.log(data);
            var tbl = '';
            for (var i = 0; i < data.length; i++) {
              var no = i + 1;
              tbl += '<tr>';
              tbl += '<td>' + no + '</td>';
              tbl += '<td>' + data[i].tanggal_absen + '</td>';
              tbl += '<td>' + data[i].tingkat_kelas + ' ' + data[i].kelas + '</td>';
              tbl += '<td>' + data[i].mapel + '</td>';
              tbl += '<td><button class="btn btn-warning btn-sm" type="button" onclick="editabsen(\'' + data[i].kd_absen + '\')" title="Ubah Data"><i class="fa fa-edit"></i></button><button class="btn btn-danger btn-sm" type="button" onclick="deleteabsen(\'' + data[i].kd_absen + '\')" title="Hapus Data"><i class="fa fa-trash"></i></button></td>';
              tbl += '</tr>';
            }
            $('#tblKehadiran tbody').append(tbl);            
          } else {
            var tbl = '<tr><td colspan="5">NO DATA AVAILABLE IN TABLE</td></tr>';
            $('#tblKehadiran tbody').append(tbl);
          }
        }
      });
    }

    function filterPengetahuan(){
      var id_kelas = $("#Kelas").val();
      var id_gurumapel = $("#Mapel").val();
      $('#tblPengetahuan tbody tr').remove();
      $.ajax({
        type: 'POST',
        url: '<?php echo e(url("getPengetahuan")); ?>',
        data: {
          'id_kelas': id_kelas,
          'id_gurumapel': id_gurumapel,
          "_token" : "<?php echo e(csrf_token()); ?>"
        },
        dataType: 'json',
        success: function (data) {
          if (data != 'fail') {
            console.log(data);
            var tbl = '';
            for (var i = 0; i < data.length; i++) {
              var no = i + 1;
              tbl += '<tr>';
              tbl += '<td>' + no + '</td>';
              tbl += '<td>' + data[i].mapel + '</td>';
              tbl += '<td>' + data[i].tingkat_kelas + ' ' + data[i].kelas + '</td>';
              tbl += '<td>' + data[i].tahun_ajaran + '</td>';
              tbl += '<td>' + data[i].semester + '</td>';
              tbl += '<td><button class="btn btn-warning btn-sm" type="button" onclick="editPengetahuan(\'' + data[i].kd_pengetahuan + '\')" title="Ubah Data"><i class="fa fa-edit"></i></button><button class="btn btn-danger btn-sm" type="button" onclick="deletePengetahuan(\'' + data[i].kd_pengetahuan + '\')" title="Hapus Data"><i class="fa fa-trash"></i></button></td>';
              tbl += '</tr>';
            }
            $('#tblPengetahuan tbody').append(tbl);
          } else {
            var tbl = '<tr><td colspan="5">NO DATA AVAILABLE IN TABLE</td></tr>';
            $('#tblPengetahuan tbody').append(tbl);
          }
        }
      });
    }

    function filterKeterampilan(){
      var id_kelas = $("#Kelas").val();
      var id_gurumapel = $("#Mapel").val();
      $('#tblKeterampilan tbody tr').remove();
      $.ajax({
        type: 'POST',
        url: '<?php echo e(url("getKeterampilan")); ?>',
        data: {
          'id_kelas': id_kelas,
          'id_gurumapel': id_gurumapel,
          "_token" : "<?php echo e(csrf_token()); ?>"
        },
        dataType: 'json',
        success: function (data) {
          if (data != 'fail') {
            console.log(data);
            var tbl = '';
            for (var i = 0; i < data.length; i++) {
              var no = i + 1;
              tbl += '<tr>';
              tbl += '<td>' + no + '</td>';
              tbl += '<td>' + data[i].mapel + '</td>';
              tbl += '<td>' + data[i].tingkat_kelas + ' ' + data[i].kelas + '</td>';
              tbl += '<td>' + data[i].tahun_ajaran + '</td>';
              tbl += '<td>' + data[i].semester + '</td>';
              tbl += '<td><button class="btn btn-warning btn-sm" type="button" onclick="editKeterampilan(\'' + data[i].kd_keterampilan + '\')" title="Ubah Data"><i class="fa fa-edit"></i></button><button class="btn btn-danger btn-sm" type="button" onclick="deleteKeterampilan(\'' + data[i].kd_keterampilan + '\')" title="Hapus Data"><i class="fa fa-trash"></i></button></td>';
              tbl += '</tr>';
            }
            $('#tblKeterampilan tbody').append(tbl);
          } else {
            var tbl = '<tr><td colspan="5">NO DATA AVAILABLE IN TABLE</td></tr>';
            $('#tblKeterampilan tbody').append(tbl);
          }
        }
      });
    }

    function filterSikap(){
      var id_kelas = $("#Kelas").val();
      var id_gurumapel = $("#Mapel").val();
      $('#tblSikap tbody tr').remove();
      $.ajax({
        type: 'POST',
        url: '<?php echo e(url("getSikap")); ?>',
        data: {
          'id_kelas': id_kelas,
          'id_gurumapel': id_gurumapel,
          "_token" : "<?php echo e(csrf_token()); ?>"
        },
        dataType: 'json',
        success: function (data) {
          if (data != 'fail') {
            console.log(data);
            var tbl = '';
            for (var i = 0; i < data.length; i++) {
              var no = i + 1;
              tbl += '<tr>';
              tbl += '<td>' + no + '</td>';
              tbl += '<td>' + data[i].mapel + '</td>';
              tbl += '<td>' + data[i].tingkat_kelas + ' ' + data[i].kelas + '</td>';
              tbl += '<td>' + data[i].tahun_ajaran + '</td>';
              tbl += '<td>' + data[i].semester + '</td>';
              tbl += '<td><button class="btn btn-warning btn-sm" type="button" onclick="editSikap(\'' + data[i].kd_sikap + '\')" title="Ubah Data"><i class="fa fa-edit"></i></button><button class="btn btn-danger btn-sm" type="button" onclick="deleteSikap(\'' + data[i].kd_sikap + '\')" title="Hapus Data"><i class="fa fa-trash"></i></button></td>';
              tbl += '</tr>';
            }
            $('#tblSikap tbody').append(tbl);
          } else {
            var tbl = '<tr><td colspan="5">NO DATA AVAILABLE IN TABLE</td></tr>';
            $('#tblSikap tbody').append(tbl);
          }
        }
      });
    }
  </script>

  <!-- Kehadiran -->
  <script type="text/javascript">
    function addKehadiran() {
      var id_kelas = $("#Kelas").val();
      var id_gurumapel = $("#Mapel").val();
      if (id_kelas == "0" || id_gurumapel == "0") {
        swal("Mohon Pilih Kelas Atau Mapel !", "Mohon Coba Lagi", "error");
      } else {
        $("#ModalTambahAbsen").modal('show');
        $("#ddlAbsenKelas").val(id_kelas).find("option[value=" + id_kelas +"]").attr('selected', true);
        $("#ddlAbsenMapel").val(id_gurumapel).find("option[value=" + id_gurumapel +"]").attr('selected', true);
        $("#inputkelas").val(id_kelas);
        $("#inputmapel").val(id_gurumapel);
        $('#listsiswa tbody tr').remove();
        $.ajax({
          type: 'POST',
          url: '<?php echo e(url("getsiswa")); ?>',
          data: {
            'id_kelas': id_kelas,
            "_token" : "<?php echo e(csrf_token()); ?>"
          },
          dataType: 'json',
          error: function (xhr, ajaxOptions, thrownError) {
            swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
          },
          success: function (data) {
            if (data != 'fail') {
              console.log(data);
              var tbl = '';
              for (var i = 0; i < data.length; i++) {
                var no = i + 1;
                tbl += '<tr>';
                tbl += '<td>' + no + '</td>';
                tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
                tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
                tbl += '<td><div class="btn-group btn-group-toggle btn-group-colors event-tag" data-toggle="buttons"><label class="btn bg-success"><input type="radio" name="status['+i+']" value="masuk" required></label>&nbsp;<label class="btn bg-info"><input type="radio" name="status['+i+']" value="izin" required ></label>&nbsp;<label class="btn bg-warning"><input type="radio" name="status['+i+']" value="sakit" required></label>&nbsp;<label class="btn bg-danger"><input type="radio" name="status['+i+']" value="alfa" required></label></div></td>';
                tbl += '</tr>';
              }
              $('#listsiswa tbody').append(tbl);
            }
          }
        });
      }
    }

    function editabsen(id){
      $.ajax({
        url: '<?php echo e(url("editabsen")); ?>',
        type: 'POST',
        data: {
          "kd_absen" : id,
          "_token" : "<?php echo e(csrf_token()); ?>",
        },
        dataType: "JSON",
        error: function (xhr, ajaxOptions, thrownError) {
          swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
        },
        success: function(data) {
          if (data != 'fail') {
            console.log(data);
            editsiswa(data.kd_absen);
            $("#ModalEditAbsen").modal('show');
            $("#kd_absen").val(data.kd_absen);
            $("#id_kelas").val(data.id_kelas);
            $("#kelas").text(data.tingkat_kelas + ' ' + data.kelas);
            $("#mapel").text(data.mapel);
            $("#etanggalAbsen").val(data.tanggal_absen);
            $("#eddlAbsenKelas").val(data.id_kelas).find("option[value=" + data.id_kelas +"]").attr('selected', true);
            $("#eddlAbsenMapel").val(data.id_gurumapel).find("option[value=" + data.id_gurumapel +"]").attr('selected', true);
              // $("#nama_siswa").text(data.nama_siswa);
              // $("input[name='status']").val(data.status).attr('checked', true);
            }else{
              swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
            }
          }
        });
    }

    function deleteabsen(id){
      swal({
        title: "Apa Absen Ingin Dihapus?",
        text: "Jika dihapus data tidak bisa dikembalikan lagi!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
          $.ajax({
            url: '<?php echo e(url("deleteabsen")); ?>',
            type: 'POST',
            data: {
              "id" : id,
              "_token" : "<?php echo e(csrf_token()); ?>",
            },
            dataType: "HTML",
            error: function (xhr, ajaxOptions, thrownError) {
              swal("Gagal Menghapus !", "Mohon Coba Lagi", "error");
            },
            success: function(data) {
              if (data == 'success') {
                swal("Berhasil !", "Data Berhasil Dihapus !", "success");
                setTimeout(function(){
                  window.location.reload();
                }, 1000);
              }else{
                swal("Gagal !", "Data Gagal Dihapus !", "danger");
              }
            }
          });
        } else {
        }
      });
    } 

    function tambahsiswa(){
      var id_kelas = $("#ddlAbsenKelas").val();
      $('#listsiswa tbody tr').remove();
      $.ajax({
        type: 'POST',
        url: '<?php echo e(url("getsiswa")); ?>',
        data: {
          'id_kelas': id_kelas,
          "_token" : "<?php echo e(csrf_token()); ?>"
        },
        dataType: 'json',
        error: function (xhr, ajaxOptions, thrownError) {
          swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
        },
        success: function (data) {
          if (data != 'fail') {
            console.log(data);
            var tbl = '';
            for (var i = 0; i < data.length; i++) {
              var no = i + 1;
              tbl += '<tr>';
              tbl += '<td>' + no + '</td>';
              tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
              tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
              tbl += '<td><div class="btn-group btn-group-toggle btn-group-colors event-tag" data-toggle="buttons"><label class="btn bg-success"><input type="radio" name="status['+i+']" value="masuk" required></label>&nbsp;<label class="btn bg-info"><input type="radio" name="status['+i+']" value="izin" required ></label>&nbsp;<label class="btn bg-warning"><input type="radio" name="status['+i+']" value="sakit" required></label>&nbsp;<label class="btn bg-danger"><input type="radio" name="status['+i+']" value="alfa" required></label></div></td>';
              tbl += '</tr>';
            }
            $('#listsiswa tbody').append(tbl);
          }
        }
      });
    }

    function editsiswa(kd_absen){
      $('#elistsiswa tbody tr').remove();
      $.ajax({
        type: 'POST',
        url: '<?php echo e(url("egetsiswa")); ?>',
        data: {
          'kd_absen': kd_absen,
          "_token" : "<?php echo e(csrf_token()); ?>"
        },
        dataType: 'json',
        error: function (xhr, ajaxOptions, thrownError) {
          swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
        },
        success: function (data) {
          if (data != 'fail') {
            console.log(data);
            var tbl = '';
            for (var i = 0; i < data.length; i++) {
              var id = data[i].id_absen_detail;
              var nama = data[i].nama_siswa;
              var status = data[i].status;
              var no = i + 1;
              tbl += '<tr>';
              tbl += '<td>' + no + '</td>';
              tbl += '<td style="display: none"><input type="text" name="id_detail[]" value="' + data[i].id_absen_detail + '" hidden></td>';
              tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_siswa + '" style="background-color: #f7fafc; border: none" readonly></td>';
              if (data[i].status == "masuk") {
                tbl += '<td><div class="btn-group btn-group-toggle btn-group-colors event-tag" data-toggle="buttons"><label class="btn bg-success active" onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "masuk" + '\')"><input type="radio" name="status['+i+']" value="masuk" id="masuk'+i+'"></label>&nbsp;<label class="btn bg-info" onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "izin" + '\')"><input type="radio" name="status['+i+']" value="izin" id="izin'+i+'"></label>&nbsp;<label class="btn bg-warning" onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "sakit" + '\')"><input type="radio" name="status['+i+']" value="sakit" id="sakit'+i+'"></label>&nbsp;<label class="btn bg-danger"  onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "alfa" + '\')"><input type="radio" name="status['+i+']" value="alfa" id="alfa'+i+'"></label></div></td>';
              }
              else if (data[i].status == "izin") {
                tbl += '<td><div class="btn-group btn-group-toggle btn-group-colors event-tag" data-toggle="buttons"><label class="btn bg-success" onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "masuk" + '\')"><input type="radio" name="status['+i+']" value="masuk" id="masuk'+i+'"></label>&nbsp;<label class="btn bg-info active" onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "izin" + '\')"><input type="radio" name="status['+i+']" value="izin" id="izin'+i+'"></label>&nbsp;<label class="btn bg-warning" onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "sakit" + '\')"><input type="radio" name="status['+i+']" value="sakit" id="sakit'+i+'"></label>&nbsp;<label class="btn bg-danger"  onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "alfa" + '\')"><input type="radio" name="status['+i+']" value="alfa" id="alfa'+i+'"></label></div></td>';
              }
              else if (data[i].status == "sakit") {
                tbl += '<td><div class="btn-group btn-group-toggle btn-group-colors event-tag" data-toggle="buttons"><label class="btn bg-success" onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "masuk" + '\')"><input type="radio" name="status['+i+']" value="masuk" id="masuk'+i+'"></label>&nbsp;<label class="btn bg-info" onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "izin" + '\')"><input type="radio" name="status['+i+']" value="izin" id="izin'+i+'"></label>&nbsp;<label class="btn bg-warning active" onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "sakit" + '\')"><input type="radio" name="status['+i+']" value="sakit" id="sakit'+i+'"></label>&nbsp;<label class="btn bg-danger"  onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "alfa" + '\')"><input type="radio" name="status['+i+']" value="alfa" id="alfa'+i+'"></label></div></td>';
              }
              else if (data[i].status == "alfa") {
                tbl += '<td><div class="btn-group btn-group-toggle btn-group-colors event-tag" data-toggle="buttons"><label class="btn bg-success" onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "masuk" + '\')"><input type="radio" name="status['+i+']" value="masuk" id="masuk'+i+'"></label>&nbsp;<label class="btn bg-info" onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "izin" + '\')"><input type="radio" name="status['+i+']" value="izin" id="izin'+i+'"></label>&nbsp;<label class="btn bg-warning" onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "sakit" + '\')"><input type="radio" name="status['+i+']" value="sakit" id="sakit'+i+'"></label>&nbsp;<label class="btn bg-danger active"  onclick="ubah(\'' + id + '\', \'' + nama + '\', \'' + "alfa" + '\')"><input type="radio" name="status['+i+']" value="alfa" id="alfa'+i+'"></label></div></td>';
              }
              tbl += '</tr>';
            }
            $('#elistsiswa tbody').append(tbl);
          }
        }
      });
}

function ubah(id, nama, status) {
  $.ajax({
    url: '<?php echo e(url("updateabsendetail")); ?>',
    method: 'POST',
    data: {
      'id_absen_detail': id,
      'nama_siswa': nama,
      'status': status,
      "_token" : "<?php echo e(csrf_token()); ?>"
    },
    dataType: 'JSON',
    success:function(data)
    {
      if (data == 'success') {

      }else{
        swal("Gagal !", "Data Gagal Ditambah !", "error");
      }
    }
  });
}

$('#tambahsiswa').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
    url: '<?php echo e(url("tambahKehadiran")); ?>',
    method: 'POST',
    data: form_data,
    dataType: 'JSON',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal !", "Data Gagal Ditambah !", "error");
    },
    success:function(data)
    {
      if (data == 'success') {
        swal("Berhasil !", "Data Berhasil Ditambah !", "success");
        setTimeout(function(){
          window.location.reload();
        }, 1000);
      } else if (data == 'exists') {
        swal("Gagal !", "Data Sudah Ada !", "error");
      } else {
        swal("Gagal !", "Data Gagal Ditambah !", "error");
      }
    }
  })
});

$('#updatesiswa').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
    url: '<?php echo e(url("updateabsen")); ?>',
    method: 'POST',
    data: form_data,
    dataType: 'JSON',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal !", "Data Gagal Diubah !", "error");
    },
    success:function(data)
    {
      if (data == 'success') {
        swal("Berhasil !", "Data Berhasil Diubah !", "success");
        setTimeout(function(){
          window.location.reload();
        }, 1000);
      }else{
        swal("Gagal !", "Data Gagal Diubah !", "error");
      }
    }
  })
});
</script>

<!-- Jurnal -->
<script type="text/javascript">
  function addJurnal() {
    var id_kelas = $("#Kelas").val();
    var id_gurumapel = $("#Mapel").val();
    if (id_kelas == "0" || id_gurumapel == "0") {
      swal("Mohon Pilih Kelas Atau Mapel !", "Mohon Coba Lagi", "error");
    } else {
      $("#ModalTambahJurnal").modal('show');
      $("#ddlKelas").val(id_kelas).find("option[value=" + id_kelas +"]").attr('selected', true);
      $("#ddlJurnalMapel").val(id_gurumapel).find("option[value=" + id_gurumapel +"]").attr('selected', true);
      $("#inputkelas").val(id_kelas);
      $("#inputmapel").val(id_gurumapel);
    }
  }

  function tambahJurnal(){
    var id_guru = "1";
    var id_gurumapel = $("#ddlJurnalMapel").val();
    var id_kelas = $("#ddlKelas").val();
    var tanggal = $("#tanggalJurnal").val();
    var kompetensi = $("#kompetensi").val();
    var pertemuan = $("#pertemuan").val();
    var materi = $("#materi").val();
    var keterangan = $("#keterangan").val();

    if (id_gurumapel == "") {
      swal("Mohon Pilih Mata Pelajaran !", "Mohon Coba Lagi", "error");
    }
    else if (tanggal == "") {
      swal("Mohon Pilih Tanggal !", "Mohon Coba Lagi", "error");
    }
    else if (id_kelas == "") {
      swal("Mohon Pilih Kelas !", "Mohon Coba Lagi", "error");
    }
    else if (pertemuan == "") {
      swal("Mohon Isi Pertemuan !", "Mohon Coba Lagi", "error");
    }
    else if (kompetensi == "") {
      swal("Mohon Pilih Kompetensi !", "Mohon Coba Lagi", "error");
    }
    else if (materi == "") {
      swal("Mohon Isi Materi !", "Mohon Coba Lagi", "error");
    }
    else {
      $.ajax({
        url: '<?php echo e(url("tambahJurnal")); ?>',
        type: 'POST',
        data: {
          "id_guru" : id_guru,
          "id_gurumapel" : id_gurumapel,
          "id_kelas" : id_kelas,
          "tanggal" : tanggal,
          "materi" : materi,
          "pertemuan" : pertemuan,
          "kompetensi" : kompetensi,
          "keterangan" : keterangan,
          "_token" : "<?php echo e(csrf_token()); ?>",
        },
        dataType: "HTML",
        error: function (xhr, ajaxOptions, thrownError) {
          swal("Gagal Menambahkan !", "Mohon Coba Lagi", "error");
        },
        success: function(data) {
          if (data == 'success') {
            swal("Berhasil !", "Data Berhasil Ditambah !", "success");
            setTimeout(function(){
              window.location.reload();
            }, 1000);
          }else{
            swal("Gagal !", "Data Gagal Ditambah !", "error");
          }
        }
      });
    }
  } 

  function editJurnal(id){
    $.ajax({
      url: '<?php echo e(url("editJurnal")); ?>',
      type: 'POST',
      data: {
        "id_jurnal" : id,
        "_token" : "<?php echo e(csrf_token()); ?>",
      },
      dataType: "JSON",
      error: function (xhr, ajaxOptions, thrownError) {
        swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
      },
      success: function(data) {
        if (data != 'fail') {
          console.log(data);
          $("#ModalEditJurnal").modal('show');
          $("#id_jurnal").val(data.id_jurnal);
          $("#eddlJurnalMapel").val(data.id_gurumapel).find("option[value=" + data.id_gurumapel +"]").attr('selected', true);
          $("#eddlKelas").val(data.id_kelas).find("option[value=" + data.id_kelas +"]").attr('selected', true);
          $("#emateri").val(data.materi);
          $("#eketerangan").val(data.keterangan);
          $("#etanggalJurnal").val(data.tanggal);
          $("#epertemuan").val(data.pertemuan);
          $("#ekompetensi").val(data.kompetensi);
        }else{
          swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
        }
      }
    });
  }

  function updateJurnal(){
    if ($("#eddlJurnalMapel").val() == "") {
      swal("Mohon Pilih Mata Pelajaran !", "Mohon Coba Lagi", "error");
    }
    else if ($("#etanggalJurnal").val() == "") {
      swal("Mohon Pilih Tanggal !", "Mohon Coba Lagi", "error");
    }
    else if ($("#eddlKelas").val() == "") {
      swal("Mohon Pilih Kelas !", "Mohon Coba Lagi", "error");
    }
    else if ($("#emateri").val() == "") {
      swal("Mohon Isi Materi !", "Mohon Coba Lagi", "error");
    }
    else if ($("#epertemuan").val() == "") {
      swal("Mohon Isi Pertemuan !", "Mohon Coba Lagi", "error");
    }
    else if ($("#ekompetensi").val() == "") {
      swal("Mohon Isi Kompetensi !", "Mohon Coba Lagi", "error");
    }
    else {
      swal({
        title: "Apa Data Tersebut Ingin Diedit?",
        text: "Jika Diedit data tidak bisa dikembalikan lagi!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
          var id_jurnal = $("#id_jurnal").val();
          var id_gurumapel = $("#eddlJurnalMapel").val();
          var id_kelas = $("#eddlKelas").val();
          var tanggal = $("#etanggalJurnal").val();
          var materi = $("#emateri").val();
          var keterangan = $("#eketerangan").val();
          var pertemuan = $("#epertemuan").val();
          var kompetensi = $("#ekompetensi").val();

          $.ajax({
            url: '<?php echo e(url("updateJurnal")); ?>',
            type: 'POST',
            data: {
              "id_jurnal" : id_jurnal,
              "id_gurumapel" : id_gurumapel,
              "id_kelas" : id_kelas,
              "tanggal" : tanggal,
              "materi" : materi,
              "keterangan" : keterangan,
              "pertemuan" : pertemuan,
              "kompetensi" : kompetensi,
              "_token" : "<?php echo e(csrf_token()); ?>",
            },
            dataType: "HTML",
            error: function (xhr, ajaxOptions, thrownError) {
              swal("Gagal Merubah !", "Mohon Coba Lagi", "error");
            },
            success: function(data) {
              if (data == 'success') {
                swal("Berhasil !", "Data Berhasil Diubah !", "success");
                setTimeout(function(){
                  window.location.reload();
                }, 1000);
              }else{
                swal("Gagal !", "Data Gagal Diubah !", "error");
              }
            }
          });
        } else {
        }
      });
    }
  }

  function deleteJurnal(id){
    swal({
      title: "Apa Jurnal Ingin Dihapus?",
      text: "Jika dihapus data tidak bisa dikembalikan lagi!",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
      if (willDelete) {
        $.ajax({
          url: '<?php echo e(url("deleteJurnal")); ?>',
          type: 'POST',
          data: {
            "id" : id,
            "_token" : "<?php echo e(csrf_token()); ?>",
          },
          dataType: "HTML",
          error: function (xhr, ajaxOptions, thrownError) {
            swal("Gagal Menghapus !", "Mohon Coba Lagi", "error");
          },
          success: function(data) {
            if (data == 'success') {
              swal("Berhasil !", "Data Berhasil Dihapus !", "success");
              setTimeout(function(){
                window.location.reload();
              }, 1000);
            }else{
              swal("Gagal !", "Data Gagal Dihapus !", "danger");
            }
          }
        });
      } else {
      }
    });
  } 
</script>

<!-- Pengetahuan -->
<script type="text/javascript">
  function addPengetahuan() {
    var id_kelas = $("#Kelas").val();
    var id_gurumapel = $("#Mapel").val();
    if (id_kelas == "0" || id_gurumapel == "0") {
      swal("Mohon Pilih Kelas Atau Mapel !", "Mohon Coba Lagi", "error");
    } else {
      $("#ModalTambahPengetahuan").modal('show');
      $("#ddlKelas").val(id_kelas).find("option[value=" + id_kelas +"]").attr('selected', true);
      $("#ddlMapel").val(id_gurumapel).find("option[value=" + id_gurumapel +"]").attr('selected', true);
      $("#inputkelas").val(id_kelas);
      $("#inputmapel").val(id_gurumapel);
    }
  }

  function changepengetahuan(){
    $('#listsiswa tbody').remove();
    $('#listsiswa thead').remove();
    var id_kelas = $("#Kelas").val();
    var id_gurumapel = $("#Mapel").val();
    var valuedata = $("#ddlPenilaian").val();
    $.ajax({
      type: 'POST',
      url: '<?php echo e(url("getsiswa")); ?>',
      data: {
        'id_kelas': id_kelas,
        "_token" : "<?php echo e(csrf_token()); ?>"
      },
      dataType: 'json',
      error: function (xhr, ajaxOptions, thrownError) {
        swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
      },
      success: function (data) {
        if (data != 'fail') {
            // console.log(data);
            var tbl = '';
            if (valuedata == '1' || valuedata == '2' || valuedata == '3' || valuedata == '4' || valuedata == '5') {
              tbl += '<thead class="thead-light"><tr><th rowspan="2" style="min-width: 50px">NO</th><th rowspan="2" style="min-width: 200px">NAMA PESERTA DIDIK</th><th colspan="5">KD <input type="text" name="kd" class="form-control kd text-center"></th></tr><tr><th>TES TULIS</th><th>TUGAS</th><th>LAINNYA</th><th>RERATA</th><th>NH</th></tr></thead><tbody>';
              for (var i = 0; i < data.length; i++) {
                var no = i + 1;
                tbl += '<tr>';
                tbl += '<td>' + no + '</td>';
                tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
                tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
                tbl += '<td><input type="text" class="form-control" name="tes_tulis[]"></td><td><input type="text" class="form-control" name="tugas[]"></td><td><input type="text" class="form-control" name="lain[]"></td><td><input type="text" class="form-control" name="rerata[]"></td><td><input type="text" class="form-control" name="nh[]"></td>';
                tbl += '</tr>';
              }
            }else if(valuedata == '6'){
              tbl += '<thead class="thead-light"><tr><th>NO</th><th>NAMA PESERTA DIDIK</th><th >RERATA NH</th></tr></thead><tbody>';
              for (var i = 0; i < data.length; i++) {
                var no = i + 1;
                tbl += '<tr>';
                tbl += '<td>' + no + '</td>';
                tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
                tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
                tbl += '<td><input type="text" class="form-control" name="rerata_nh[]"></td>';
                tbl += '</tr>';
              }
            }else if(valuedata == '7'){
              tbl += '<thead class="thead-light"><tr><th>NO</th><th>NAMA PESERTA DIDIK</th><th >PTS</th></tr></thead><tbody>';
              for (var i = 0; i < data.length; i++) {
                var no = i + 1;
                tbl += '<tr>';
                tbl += '<td>' + no + '</td>';
                tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
                tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
                tbl += '<td><input type="text" class="form-control" name="pts[]"></td>';
                tbl += '</tr>';
              }
            }else if(valuedata == '8'){
              tbl += '<thead class="thead-light"><tr><th>NO</th><th>NAMA PESERTA DIDIK</th><th >PAS / PAT</th></tr></thead><tbody>';
              for (var i = 0; i < data.length; i++) {
                var no = i + 1;
                tbl += '<tr>';
                tbl += '<td>' + no + '</td>';
                tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
                tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
                tbl += '<td><input type="text" class="form-control" name="pas_pat[]"></td>';
                tbl += '</tr>';
              }
            }else if(valuedata == '9'){
              tbl += '<thead class="thead-light"><tr><th>NO</th><th>NAMA PESERTA DIDIK</th><th >NILAI AKHIR</th></tr></thead><tbody>';
              for (var i = 0; i < data.length; i++) {
                var no = i + 1;
                tbl += '<tr>';
                tbl += '<td>' + no + '</td>';
                tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
                tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
                tbl += '<td><input type="text" class="form-control" name="nilai_akhir[]"></td>';
                tbl += '</tr>';
              }
            }else if(valuedata == '10'){
              tbl += '<thead class="thead-light"><tr><th>NO</th><th>NAMA PESERTA DIDIK</th><th >KETERANGAN</th></tr></thead><tbody>';
              for (var i = 0; i < data.length; i++) {
                var no = i + 1;
                tbl += '<tr>';
                tbl += '<td>' + no + '</td>';
                tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
                tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
                tbl += '<td><input type="text" class="form-control" name="keterangan[]"></td>';
                tbl += '</tr>';
              }
            }
            
            tbl += "</tbody>";
            $('#listsiswa').append(tbl);
          }
        }
      });
}

function listPengetahuan(){
  var id_kelas = $("#ddlKelas").val();
  $('#listsiswa tbody tr').remove();
  $.ajax({
    type: 'POST',
    url: '<?php echo e(url("getsiswa")); ?>',
    data: {
      'id_kelas': id_kelas,
      "_token" : "<?php echo e(csrf_token()); ?>"
    },
    dataType: 'json',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
    },
    success: function (data) {
      if (data != 'fail') {
        console.log(data);
        var tbl = '';
        for (var i = 0; i < data.length; i++) {
          var no = i + 1;
          tbl += '<tr>';
          tbl += '<td>' + no + '</td>';
          tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
          tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
          tbl += '<td><input type="text" class="form-control" name="tes_tulis1[]"></td><td><input type="text" class="form-control" name="tugas1[]"></td><td><input type="text" class="form-control" name="lain1[]"></td><td><input type="text" class="form-control" name="rerata1[]"></td><td><input type="text" class="form-control" name="nh1[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="tes_tulis2[]"></td><td><input type="text" class="form-control" name="tugas2[]"></td><td><input type="text" class="form-control" name="lain2[]"></td><td><input type="text" class="form-control" name="rerata2[]"></td><td><input type="text" class="form-control" name="nh2[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="tes_tulis3[]"></td><td><input type="text" class="form-control" name="tugas3[]"></td><td><input type="text" class="form-control" name="lain3[]"></td><td><input type="text" class="form-control" name="rerata3[]"></td><td><input type="text" class="form-control" name="nh3[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="tes_tulis4[]"></td><td><input type="text" class="form-control" name="tugas4[]"></td><td><input type="text" class="form-control" name="lain4[]"></td><td><input type="text" class="form-control" name="rerata4[]"></td><td><input type="text" class="form-control" name="nh4[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="tes_tulis5[]"></td><td><input type="text" class="form-control" name="tugas5[]"></td><td><input type="text" class="form-control" name="lain5[]"></td><td><input type="text" class="form-control" name="rerata5[]"></td><td><input type="text" class="form-control" name="nh5[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="rerata_nh[]"></td><td><input type="text" class="form-control" name="pts[]"></td><td><input type="text" class="form-control" name="pas_pat[]"></td><td><input type="text" class="form-control" name="nilai_akhir[]"></td><td><input type="text" class="form-control" name="keterangan[]"></td>';
          tbl += '</tr>';
        }
        $('#listsiswa tbody').append(tbl);
      }
    }
  });
}

$('#tambahPengetahuan').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
    // console.log(form_data);
    $.ajax({
      url: '<?php echo e(url("tambahPengetahuan")); ?>',
      method: 'POST',
      data: form_data,
      dataType: 'JSON',
      error: function (xhr, ajaxOptions, thrownError) {
        swal("Gagal !", "Data Gagal Ditambah !", "error");
      },
      success:function(data)
      {
        if (data == 'success') {
          swal("Berhasil !", "Data Berhasil Ditambah !", "success");
          setTimeout(function(){
            window.location.reload();
          }, 1000);
        } else if (data == 'exists') {
          swal("Gagal !", "Data Sudah Ada !", "error");
        } else {
          swal("Gagal !", "Data Gagal Ditambah !", "error");
        }
      }
    })
  });

function editPengetahuan(id){
  $.ajax({
    url: '<?php echo e(url("editPengetahuan")); ?>',
    type: 'POST',
    data: {
      "kd_pengetahuan" : id,
      "_token" : "<?php echo e(csrf_token()); ?>",
    },
    dataType: "JSON",
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
    },
    success: function(data) {
      if (data != 'fail') {
        console.log(data);
        ePeng(data.kd_pengetahuan);
        $("#ModalEditPengetahuan").modal('show');
        $("#kd_pengetahuan").val(data.kd_pengetahuan);
        $("#id_kelas").val(data.id_kelas);
        $("#kelas").text(data.tingkat_kelas + ' ' + data.kelas);
        $("#mapel").text(data.mapel);
        $("#etanggal").val(data.tanggal);
        $("#eddlKelas").val(data.id_kelas).find("option[value=" + data.id_kelas +"]").attr('selected', true);
        $("#eddlMapel").val(data.id_gurumapel).find("option[value=" + data.id_gurumapel +"]").attr('selected', true);
        $("#eddlTahunAjaran").val(data.tahun_ajaran).find("option[value=' + data.tahun_ajaran +']").attr('selected', true);
        $("#eddlSemester").val(data.semester).find("option[value=' + data.semester +']").attr('selected', true);
        $("#kd1").val(data.kd1);
        $("#kd2").val(data.kd2);
        $("#kd3").val(data.kd3);
        $("#kd4").val(data.kd4);
        $("#kd5").val(data.kd5);
      }else{
        swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
      }
    }
  });
}

function ePeng(kd_pengetahuan){
  $('#elistsiswa tbody tr').remove();
  $.ajax({
    type: 'POST',
    url: '<?php echo e(url("ePeng")); ?>',
    data: {
      'kd_pengetahuan': kd_pengetahuan,
      "_token" : "<?php echo e(csrf_token()); ?>"
    },
    dataType: 'json',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
    },
    success: function (data) {
      if (data != 'fail') {
        console.log(data);
        var tbl = '';
        for (var i = 0; i < data.length; i++) {
          var id = data[i].id_pengetahuan_detail;
          var nama = data[i].nama_siswa;
          var status = data[i].status;
          var no = i + 1;
          tbl += '<tr>';
          tbl += '<td>' + no + '</td>';
          tbl += '<td style="display: none"><input type="text" name="id_detail[]" value="' + data[i].id_pengetahuan_detail + '" hidden></td>';
          tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_siswa + '" style="background-color: #f7fafc; border: none" readonly></td>';
          tbl += '<td><input type="text" class="form-control" name="tes_tulis1[]" value="'+data[i].tes_tulis1+'"></td><td><input type="text" class="form-control" name="tugas1[]" value="'+data[i].tugas1+'"></td><td><input type="text" class="form-control" name="lain1[]" value="'+data[i].lain1+'"></td><td><input type="text" class="form-control" name="rerata1[]" value="'+data[i].rerata1+'"></td><td><input type="text" class="form-control" name="nh1[]" value="'+data[i].nh1+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="tes_tulis2[]" value="'+data[i].tes_tulis2+'"></td><td><input type="text" class="form-control" name="tugas2[]" value="'+data[i].tugas2+'"></td><td><input type="text" class="form-control" name="lain2[]" value="'+data[i].lain2+'"></td><td><input type="text" class="form-control" name="rerata2[]" value="'+data[i].rerata2+'"></td><td><input type="text" class="form-control" name="nh2[]" value="'+data[i].nh2+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="tes_tulis3[]" value="'+data[i].tes_tulis3+'"></td><td><input type="text" class="form-control" name="tugas3[]" value="'+data[i].tugas3+'"></td><td><input type="text" class="form-control" name="lain3[]" value="'+data[i].lain3+'"></td><td><input type="text" class="form-control" name="rerata3[]" value="'+data[i].rerata3+'"></td><td><input type="text" class="form-control" name="nh3[]" value="'+data[i].nh3+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="tes_tulis4[]" value="'+data[i].tes_tulis4+'"></td><td><input type="text" class="form-control" name="tugas4[]" value="'+data[i].tugas4+'"></td><td><input type="text" class="form-control" name="lain4[]" value="'+data[i].lain4+'"></td><td><input type="text" class="form-control" name="rerata4[]" value="'+data[i].rerata4+'"></td><td><input type="text" class="form-control" name="nh4[]" value="'+data[i].nh4+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="tes_tulis5[]" value="'+data[i].tes_tulis5+'"></td><td><input type="text" class="form-control" name="tugas5[]" value="'+data[i].tugas5+'"></td><td><input type="text" class="form-control" name="lain5[]" value="'+data[i].lain5+'"></td><td><input type="text" class="form-control" name="rerata5[]" value="'+data[i].rerata5+'"></td><td><input type="text" class="form-control" name="nh5[]" value="'+data[i].nh5+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="rerata_nh[]" value="'+data[i].rerata_nh+'"></td><td><input type="text" class="form-control" name="pts[]" value="'+data[i].pts+'"></td><td><input type="text" class="form-control" name="pas_pat[]" value="'+data[i].pas_pat+'"></td><td><input type="text" class="form-control" name="nilai_akhir[]" value="'+data[i].nilai_akhir+'"></td><td><input type="text" class="form-control" name="keterangan[]" value="'+data[i].keterangan+'"></td>';
          tbl += '</tr>';
        }
        $('#elistsiswa tbody').append(tbl);
      }
    }
  });
}

$('#updatePengetahuan').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
    url: '<?php echo e(url("updatePengetahuan")); ?>',
    method: 'POST',
    data: form_data,
    dataType: 'JSON',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal !", "Data Gagal Diubah !", "error");
    },
    success:function(data)
    {
      if (data == 'success') {
        swal("Berhasil !", "Data Berhasil Diubah !", "success");
        setTimeout(function(){
          window.location.reload();
        }, 1000);
      }else{
        swal("Gagal !", "Data Gagal Diubah !", "error");
      }
    }
  })
});

function deletePengetahuan(id){
  swal({
    title: "Apa Data Ingin Dihapus?",
    text: "Jika dihapus data tidak bisa dikembalikan lagi!",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  })
  .then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: '<?php echo e(url("deletePengetahuan")); ?>',
        type: 'POST',
        data: {
          "id" : id,
          "_token" : "<?php echo e(csrf_token()); ?>",
        },
        dataType: "HTML",
        error: function (xhr, ajaxOptions, thrownError) {
          swal("Gagal Menghapus !", "Mohon Coba Lagi", "error");
        },
        success: function(data) {
          if (data == 'success') {
            swal("Berhasil !", "Data Berhasil Dihapus !", "success");
            setTimeout(function(){
              window.location.reload();
            }, 1000);
          }else{
            swal("Gagal !", "Data Gagal Dihapus !", "danger");
          }
        }
      });
    } else {
    }
  });
} 
</script>

<!-- Keterampilan -->
<script type="text/javascript">
  function addKeterampilan() {
    var id_kelas = $("#Kelas").val();
    var id_gurumapel = $("#Mapel").val();
    if (id_kelas == "0" || id_gurumapel == "0") {
      swal("Mohon Pilih Kelas Atau Mapel !", "Mohon Coba Lagi", "error");
    } else {
      $("#ModalTambahKeterampilan").modal('show');
      $("#ddlKelas").val(id_kelas).find("option[value=" + id_kelas +"]").attr('selected', true);
      $("#ddlMapel").val(id_gurumapel).find("option[value=" + id_gurumapel +"]").attr('selected', true);
      $("#inputkelas").val(id_kelas);
      $("#inputmapel").val(id_gurumapel);
    }
  }

  function changeketerampilan(){
   var id_kelas = $("#ddlKelas").val();
   var valuedata = $("#ddlPenilaian").val();
   $('#listsiswa tbody').remove();
   $('#listsiswa thead').remove();
   $.ajax({
    type: 'POST',
    url: '<?php echo e(url("getsiswa")); ?>',
    data: {
      'id_kelas': id_kelas,
      "_token" : "<?php echo e(csrf_token()); ?>"
    },
    dataType: 'json',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
    },
    success: function (data) {
      if (data != 'fail') {
        var tbl = '';
        if (valuedata == 1 || valuedata == 2 || valuedata == 3 || valuedata == 4 || valuedata == 5) {
         tbl += '<thead class="thead-light"><tr><th rowspan="2" style="min-width: 50px">NO</th><th rowspan="2" style="min-width: 200px">NAMA PESERTA DIDIK</th><th colspan="5">KD <input type="text" name="kd" class="form-control kd text-center"></th></tr><tr><th>KINERJA 1</th><th style="font-size: 9px">KINERJA 2</th><th style="font-size: 8px">PORTOFOLIO</th><th>OPTIMUM</th><th>REMIDI</th></tr></thead>';
         for (var i = 0; i < data.length; i++) {
          var no = i + 1;
          tbl += '<tbody><tr>';
          tbl += '<td>' + no + '</td>';
          tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
          tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
          tbl += '<td><input type="text" class="form-control" name="kinerja1[]"></td><td><input type="text" class="form-control" name="kjinerja2[]"></td><td><input type="text" class="form-control" name="portofolio[]"></td><td><input type="text" class="form-control" name="optimum[]"></td><td><input type="text" class="form-control" name="remidi[]"></td>';
          tbl += '</tr></tbody>';
        }
      }else if(valuedata == 6){
        tbl += '<thead class="thead-light"><tr><th>NO</th><th>NAMA PESERTA DIDIK</th><th>NILAI AKHIR</th></tr></thead>';
        for (var i = 0; i < data.length; i++) {
          var no = i + 1;
          tbl += '<tbody><tr>';
          tbl += '<td>' + no + '</td>';
          tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
          tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
          tbl += '<td><input type="text" class="form-control" name="nilai_akhir[]"></td>';
          tbl += '</tr></tbody>';
        }
      }else if(valuedata == 7){
        tbl += '<thead class="thead-light"><tr><th>NO</th><th>NAMA PESERTA DIDIK</th><th>NILAI AKHIR</th></tr></thead>';
        for (var i = 0; i < data.length; i++) {
          var no = i + 1;
          tbl += '<tbody><tr>';
          tbl += '<td>' + no + '</td>';
          tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
          tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
          tbl += '<td><input type="text" class="form-control" name="keterangan[]"></td>';
          tbl += '</tr></tbody>';
        }
      }

      $('#listsiswa').append(tbl);
    }
  }
});
 }

 function listKeterampilan(){
  var id_kelas = $("#ddlKelas").val();
  $('#listsiswa tbody tr').remove();
  $.ajax({
    type: 'POST',
    url: '<?php echo e(url("getsiswa")); ?>',
    data: {
      'id_kelas': id_kelas,
      "_token" : "<?php echo e(csrf_token()); ?>"
    },
    dataType: 'json',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
    },
    success: function (data) {
      if (data != 'fail') {
        console.log(data);
        var tbl = '';
        for (var i = 0; i < data.length; i++) {
          var no = i + 1;
          tbl += '<tr>';
          tbl += '<td>' + no + '</td>';
          tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
          tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
          tbl += '<td><input type="text" class="form-control" name="kinerja1_1[]"></td><td><input type="text" class="form-control" name="kjinerja2_1[]"></td><td><input type="text" class="form-control" name="portofolio1[]"></td><td><input type="text" class="form-control" name="optimum1[]"></td><td><input type="text" class="form-control" name="remidi1[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="kinerja1_2[]"></td><td><input type="text" class="form-control" name="kjinerja2_2[]"></td><td><input type="text" class="form-control" name="portofolio2[]"></td><td><input type="text" class="form-control" name="optimum2[]"></td><td><input type="text" class="form-control" name="remidi2[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="kinerja1_3[]"></td><td><input type="text" class="form-control" name="kjinerja2_3[]"></td><td><input type="text" class="form-control" name="portofolio3[]"></td><td><input type="text" class="form-control" name="optimum3[]"></td><td><input type="text" class="form-control" name="remidi3[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="kinerja1_4[]"></td><td><input type="text" class="form-control" name="kjinerja2_4[]"></td><td><input type="text" class="form-control" name="portofolio4[]"></td><td><input type="text" class="form-control" name="optimum4[]"></td><td><input type="text" class="form-control" name="remidi4[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="kinerja1_5[]"></td><td><input type="text" class="form-control" name="kjinerja2_5[]"></td><td><input type="text" class="form-control" name="portofolio5[]"></td><td><input type="text" class="form-control" name="optimum5[]"></td><td><input type="text" class="form-control" name="remidi5[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="nilai_akhir[]"></td><td><input type="text" class="form-control" name="keterangan[]"></td>';
          tbl += '</tr>';
        }
        $('#listsiswa tbody').append(tbl);
      }
    }
  });
}

$('#tambahKeterampilan').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
    url: '<?php echo e(url("tambahKeterampilan")); ?>',
    method: 'POST',
    data: form_data,
    dataType: 'JSON',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal !", "Data Gagal Ditambah !", "error");
    },
    success:function(data)
    {
      if (data == 'success') {
        swal("Berhasil !", "Data Berhasil Ditambah !", "success");
        setTimeout(function(){
          window.location.reload();
        }, 1000);
      } else if (data == 'exists') {
        swal("Gagal !", "Data Sudah Ada !", "error");
      } else {
        swal("Gagal !", "Data Gagal Ditambah !", "error");
      }
    }
  })
});

function editKeterampilan(id){
  $.ajax({
    url: '<?php echo e(url("editKeterampilan")); ?>',
    type: 'POST',
    data: {
      "kd_keterampilan" : id,
      "_token" : "<?php echo e(csrf_token()); ?>",
    },
    dataType: "JSON",
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
    },
    success: function(data) {
      if (data != 'fail') {
        console.log(data);
        eKet(data.kd_keterampilan);
        $("#ModalEditKeterampilan").modal('show');
        $("#kd_keterampilan").val(data.kd_keterampilan);
        $("#id_kelas").val(data.id_kelas);
        $("#kelas").text(data.tingkat_kelas + ' ' + data.kelas);
        $("#mapel").text(data.mapel);
        $("#etanggal").val(data.tanggal);
        $("#eddlKelas").val(data.id_kelas).find("option[value=" + data.id_kelas +"]").attr('selected', true);
        $("#eddlMapel").val(data.id_gurumapel).find("option[value=" + data.id_gurumapel +"]").attr('selected', true);
        $("#eddlTahunAjaran").val(data.tahun_ajaran).find("option[value=' + data.tahun_ajaran +']").attr('selected', true);
        $("#eddlSemester").val(data.semester).find("option[value=' + data.semester +']").attr('selected', true);
        $("#kd1").val(data.kd1);
        $("#kd2").val(data.kd2);
        $("#kd3").val(data.kd3);
        $("#kd4").val(data.kd4);
        $("#kd5").val(data.kd5);
      }else{
        swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
      }
    }
  });
}

function eKet(kd_keterampilan){
  $('#elistsiswa tbody tr').remove();
  $.ajax({
    type: 'POST',
    url: '<?php echo e(url("eKet")); ?>',
    data: {
      'kd_keterampilan': kd_keterampilan,
      "_token" : "<?php echo e(csrf_token()); ?>"
    },
    dataType: 'json',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
    },
    success: function (data) {
      if (data != 'fail') {
        console.log(data);
        var tbl = '';
        for (var i = 0; i < data.length; i++) {
          var id = data[i].id_keterampilan_detail;
          var nama = data[i].nama_siswa;
          var status = data[i].status;
          var no = i + 1;
          tbl += '<tr>';
          tbl += '<td>' + no + '</td>';
          tbl += '<td style="display: none"><input type="text" name="id_detail[]" value="' + data[i].id_keterampilan_detail + '" hidden></td>';
          tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_siswa + '" style="background-color: #f7fafc; border: none" readonly></td>';
          tbl += '<td><input type="text" class="form-control" name="kinerja1_1[]" value="'+data[i].kinerja1_1+'"></td><td><input type="text" class="form-control" name="kjinerja2_1[]" value="'+data[i].kjinerja2_1+'"></td><td><input type="text" class="form-control" name="portofolio1[]" value="'+data[i].portofolio1+'"></td><td><input type="text" class="form-control" name="optimum1[]" value="'+data[i].optimum1+'"></td><td><input type="text" class="form-control" name="remidi1[]" value="'+data[i].remidi1+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="kinerja1_2[]" value="'+data[i].kinerja1_2+'"></td><td><input type="text" class="form-control" name="kjinerja2_2[]" value="'+data[i].kjinerja2_2+'"></td><td><input type="text" class="form-control" name="portofolio2[]" value="'+data[i].portofolio2+'"></td><td><input type="text" class="form-control" name="optimum2[]" value="'+data[i].optimum2+'"></td><td><input type="text" class="form-control" name="remidi2[]" value="'+data[i].remidi2+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="kinerja1_3[]" value="'+data[i].kinerja1_3+'"></td><td><input type="text" class="form-control" name="kjinerja2_3[]" value="'+data[i].kjinerja2_3+'"></td><td><input type="text" class="form-control" name="portofolio3[]" value="'+data[i].portofolio3+'"></td><td><input type="text" class="form-control" name="optimum3[]" value="'+data[i].optimum3+'"></td><td><input type="text" class="form-control" name="remidi3[]" value="'+data[i].remidi3+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="kinerja1_4[]" value="'+data[i].kinerja1_4+'"></td><td><input type="text" class="form-control" name="kjinerja2_4[]" value="'+data[i].kjinerja2_4+'"></td><td><input type="text" class="form-control" name="portofolio4[]" value="'+data[i].portofolio4+'"></td><td><input type="text" class="form-control" name="optimum4[]" value="'+data[i].optimum4+'"></td><td><input type="text" class="form-control" name="remidi4[]" value="'+data[i].remidi4+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="kinerja1_5[]" value="'+data[i].kinerja1_5+'"></td><td><input type="text" class="form-control" name="kjinerja2_5[]" value="'+data[i].kjinerja2_5+'"></td><td><input type="text" class="form-control" name="portofolio5[]" value="'+data[i].portofolio5+'"></td><td><input type="text" class="form-control" name="optimum5[]" value="'+data[i].optimum5+'"></td><td><input type="text" class="form-control" name="remidi5[]" value="'+data[i].remidi5+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="nilai_akhir[]" value="'+data[i].nilai_akhir+'"></td><td><input type="text" class="form-control" name="keterangan[]" value="'+data[i].keterangan+'"></td>';
          tbl += '</tr>';
        }
        $('#elistsiswa tbody').append(tbl);
      }
    }
  });
}

$('#updateKeterampilan').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
    url: '<?php echo e(url("updateKeterampilan")); ?>',
    method: 'POST',
    data: form_data,
    dataType: 'JSON',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal !", "Data Gagal Diubah !", "error");
    },
    success:function(data)
    {
      if (data == 'success') {
        swal("Berhasil !", "Data Berhasil Diubah !", "success");
        setTimeout(function(){
          window.location.reload();
        }, 1000);
      }else{
        swal("Gagal !", "Data Gagal Diubah !", "error");
      }
    }
  })
});

function deleteKeterampilan(id){
  swal({
    title: "Apa Data Ingin Dihapus?",
    text: "Jika dihapus data tidak bisa dikembalikan lagi!",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  })
  .then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: '<?php echo e(url("deleteKeterampilan")); ?>',
        type: 'POST',
        data: {
          "id" : id,
          "_token" : "<?php echo e(csrf_token()); ?>",
        },
        dataType: "HTML",
        error: function (xhr, ajaxOptions, thrownError) {
          swal("Gagal Menghapus !", "Mohon Coba Lagi", "error");
        },
        success: function(data) {
          if (data == 'success') {
            swal("Berhasil !", "Data Berhasil Dihapus !", "success");
            setTimeout(function(){
              window.location.reload();
            }, 1000);
          }else{
            swal("Gagal !", "Data Gagal Dihapus !", "danger");
          }
        }
      });
    } else {
    }
  });
} 
</script>

<!-- Sikap -->
<script type="text/javascript">
  function addSikap() {
    var id_kelas = $("#Kelas").val();
    var id_gurumapel = $("#Mapel").val();
    if (id_kelas == "0" || id_gurumapel == "0") {
      swal("Mohon Pilih Kelas Atau Mapel !", "Mohon Coba Lagi", "error");
    } else {
      $("#ModalTambahSikap").modal('show');
      $("#ddlKelas").val(id_kelas).find("option[value=" + id_kelas +"]").attr('selected', true);
      $("#ddlMapel").val(id_gurumapel).find("option[value=" + id_gurumapel +"]").attr('selected', true);
      $("#inputkelas").val(id_kelas);
      $("#inputmapel").val(id_gurumapel);
}
}

function changesikap(){
  var id_kelas = $("#ddlKelas").val();
  var valuedata = $("#ddlPenilaian").val();
  $('#listsiswa tbody').remove();
  $('#listsiswa thead').remove();
  $.ajax({
    type: 'POST',
    url: '<?php echo e(url("getsiswa")); ?>',
    data: {
      'id_kelas': id_kelas,
      "_token" : "<?php echo e(csrf_token()); ?>"
    },
    dataType: 'json',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
    },
    success: function (data) {
      if (data != 'fail') {
        var tbl = '';

        if (valuedata == 1) {
          tbl += '<thead class="thead-light" style="max-height: 100px !important"><tr><th rowspan="3" style="min-width: 50px">NO</th><th rowspan="3" style="min-width: 200px">NAMA PESERTA DIDIK</th><th colspan="15">SPIRITUAL</th></tr><tr><th colspan="5">ASPEK 1</th><th colspan="5">ASPEK 2</th><th colspan="5">ASPEK 3</th></tr><tr><th class="title">KINERJA 1</th><th class="title">KINERJA 2</th><th class="title">PORTOFOLIO</th><th class="title">OPTIMUM</th><th class="title">REMIDI</th><th class="title">KINERJA 1</th><th class="title">KINERJA 2</th><th class="title">PORTOFOLIO</th><th class="title">OPTIMUM</th><th class="title">REMIDI</th><th class="title">KINERJA 1</th><th class="title">KINERJA 2</th><th class="title">PORTOFOLIO</th><th class="title">OPTIMUM</th><th class="title">REMIDI</th></tr></thead><tbody>';
          for (var i = 0; i < data.length; i++) {
            var no = i + 1;
            tbl += '<tr>';
            tbl += '<td>' + no + '</td>';
            tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
            tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
            tbl += '<td><input type="text" class="form-control" name="a1_kinerja1[]"></td><td><input type="text" class="form-control" name="a1_kjinerja2[]"></td><td><input type="text" class="form-control" name="a1_portofolio[]"></td><td><input type="text" class="form-control" name="a1_optimum[]"></td><td><input type="text" class="form-control" name="a1_remidi[]"></td>';
            tbl += '<td><input type="text" class="form-control" name="a2_kinerja1[]"></td><td><input type="text" class="form-control" name="a2_kjinerja2[]"></td><td><input type="text" class="form-control" name="a2_portofolio[]"></td><td><input type="text" class="form-control" name="a2_optimum[]"></td><td><input type="text" class="form-control" name="a2_remidi[]"></td>';
            tbl += '<td><input type="text" class="form-control" name="a3_kinerja1[]"></td><td><input type="text" class="form-control" name="a3_kjinerja2[]"></td><td><input type="text" class="form-control" name="a3_portofolio[]"></td><td><input type="text" class="form-control" name="a3_optimum[]"></td><td><input type="text" class="form-control" name="a3_remidi[]"></td>';
            tbl += '</tr></tbody>';
          }
        }else if (valuedata == 2 || valuedata == 3 || valuedata == 4 || valuedata == 5 || valuedata == 6 || valuedata == 7){
          if (valuedata == 2 ) {
            var apaini = "JUJUR";
          }else if(valuedata == 3){
            var apaini = "DISIPLIN";
          }else if(valuedata == 4){
            var apaini = "TANGGUNG JAWAB";
          }else if(valuedata == 5){
            var apaini = "PERCAYA DIRI";
          }else if(valuedata == 6){
            var apaini = "KERJA SAMA";
          }else if(valuedata == 7){
            var apaini = "SANTUN";
          }
          tbl += '<thead class="thead-light" style="max-height: 100px !important"><tr><th rowspan="2">NO</th><th rowspan="2">NAMA PESERTA DIDIK</th><th colspan="5">' + apaini + '</th></tr><tr><th>OBSERVASI</th><th>OBSERVASI</th><th>PEN. DIRI</th><th>ANTARTEMAN</th><th>JURNAL GURU</th></thead><tbody>';
          for (var i = 0; i < data.length; i++) {
            var no = i + 1;
            tbl += '<tr>';
            tbl += '<td>' + no + '</td>';
            tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
            tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
            tbl += '<td><input type="text" class="form-control" name="obs1[]"></td><td><input type="text" class="form-control" name="obs2[]"></td><td><input type="text" class="form-control" name="pd[]"></td><td><input type="text" class="form-control" name="antarteman[]"></td><td><input type="text" class="form-control" name="jurnal_guru[]"></td>';
            tbl += '</tr></tbody>';
          }
          }else if(valuedata == 8){
            tbl += '<thead class="thead-light"><tr><th>NO</th><th>NAMA PESERTA DIDIK</th><th>NILAI SIKAP</th></thead><tbody>';
            for (var i = 0; i < data.length; i++) {
              var no = i + 1;
              tbl += '<tr>';
              tbl += '<td>' + no + '</td>';
              tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
              tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
              tbl += '<td><input type="text" class="form-control" name="nilai_sikap[]"></td>';
              tbl += '</tr></tbody>';
            }
            }else if (valuedata == 9){
              tbl += '<thead class="thead-light"><tr><th>NO</th><th>NAMA PESERTA DIDIK</th><th>PREDIKAT</th></thead><tbody>';
              for (var i = 0; i < data.length; i++) {
                var no = i + 1;
                tbl += '<tr>';
                tbl += '<td>' + no + '</td>';
                tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
                tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
                tbl += '<td><input type="text" class="form-control" name="predikat[]"></td>';
                tbl += '</tr></tbody>';
              }
            }

              $('#listsiswa').append(tbl);
            }
          }
        });
}

function listSikap(){
  var id_kelas = $("#ddlKelas").val();
  $('#listsiswa tbody tr').remove();
  $.ajax({
    type: 'POST',
    url: '<?php echo e(url("getsiswa")); ?>',
    data: {
      'id_kelas': id_kelas,
      "_token" : "<?php echo e(csrf_token()); ?>"
    },
    dataType: 'json',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
    },
    success: function (data) {
      if (data != 'fail') {
        console.log(data);
        var tbl = '';
        for (var i = 0; i < data.length; i++) {
          var no = i + 1;
          tbl += '<tr>';
          tbl += '<td>' + no + '</td>';
          tbl += '<td style="display: none"><input type="text" name="id_siswa[]" value="' + data[i].id_siswa + '" hidden></td>';
          tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_lengkap + '" style="background-color: #f7fafc; border: none" readonly></td>';
          tbl += '<td><input type="text" class="form-control" name="a1_kinerja1[]"></td><td><input type="text" class="form-control" name="a1_kjinerja2[]"></td><td><input type="text" class="form-control" name="a1_portofolio[]"></td><td><input type="text" class="form-control" name="a1_optimum[]"></td><td><input type="text" class="form-control" name="a1_remidi[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="a2_kinerja1[]"></td><td><input type="text" class="form-control" name="a2_kjinerja2[]"></td><td><input type="text" class="form-control" name="a2_portofolio[]"></td><td><input type="text" class="form-control" name="a2_optimum[]"></td><td><input type="text" class="form-control" name="a2_remidi[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="a3_kinerja1[]"></td><td><input type="text" class="form-control" name="a3_kjinerja2[]"></td><td><input type="text" class="form-control" name="a3_portofolio[]"></td><td><input type="text" class="form-control" name="a3_optimum[]"></td><td><input type="text" class="form-control" name="a3_remidi[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="j_obs1[]"></td><td><input type="text" class="form-control" name="j_obs2[]"></td><td><input type="text" class="form-control" name="j_pd[]"></td><td><input type="text" class="form-control" name="j_antarteman[]"></td><td><input type="text" class="form-control" name="j_jurnal_guru[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="d_obs1[]"></td><td><input type="text" class="form-control" name="d_obs2[]"></td><td><input type="text" class="form-control" name="d_pd[]"></td><td><input type="text" class="form-control" name="d_antarteman[]"></td><td><input type="text" class="form-control" name="d_jurnal_guru[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="t_obs1[]"></td><td><input type="text" class="form-control" name="t_obs2[]"></td><td><input type="text" class="form-control" name="t_pd[]"></td><td><input type="text" class="form-control" name="t_antarteman[]"></td><td><input type="text" class="form-control" name="t_jurnal_guru[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="p_obs1[]"></td><td><input type="text" class="form-control" name="p_obs2[]"></td><td><input type="text" class="form-control" name="p_pd[]"></td><td><input type="text" class="form-control" name="p_antarteman[]"></td><td><input type="text" class="form-control" name="p_jurnal_guru[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="k_obs1[]"></td><td><input type="text" class="form-control" name="k_obs2[]"></td><td><input type="text" class="form-control" name="k_pd[]"></td><td><input type="text" class="form-control" name="k_antarteman[]"></td><td><input type="text" class="form-control" name="k_jurnal_guru[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="s_obs1[]"></td><td><input type="text" class="form-control" name="s_obs2[]"></td><td><input type="text" class="form-control" name="s_pd[]"></td><td><input type="text" class="form-control" name="s_antarteman[]"></td><td><input type="text" class="form-control" name="s_jurnal_guru[]"></td>';
          tbl += '<td><input type="text" class="form-control" name="nilai_sikap[]"></td><td><input type="text" class="form-control" name="predikat[]"></td>';
          tbl += '</tr>';
        }
        $('#listsiswa tbody').append(tbl);
      }
    }
  });
}

$('#tambahSikap').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
    url: '<?php echo e(url("tambahSikap")); ?>',
    method: 'POST',
    data: form_data,
    dataType: 'JSON',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal !", "Data Gagal Ditambah !", "error");
    },
    success:function(data)
    {
      if (data == 'success') {
        swal("Berhasil !", "Data Berhasil Ditambah !", "success");
        setTimeout(function(){
          window.location.reload();
        }, 1000);
      } else if (data == 'exists') {
        swal("Gagal !", "Data Sudah Ada !", "error");
      } else {
        swal("Gagal !", "Data Gagal Ditambah !", "error");
      }
    }
  })
});

function editSikap(id){
  $.ajax({
    url: '<?php echo e(url("editSikap")); ?>',
    type: 'POST',
    data: {
      "kd_sikap" : id,
      "_token" : "<?php echo e(csrf_token()); ?>",
    },
    dataType: "JSON",
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
    },
    success: function(data) {
      if (data != 'fail') {
        console.log(data);
        eSikap(data.kd_sikap);
        $("#ModalEditSikap").modal('show');
        $("#kd_sikap").val(data.kd_sikap);
        $("#id_kelas").val(data.id_kelas);
        $("#kelas").text(data.tingkat_kelas + ' ' + data.kelas);
        $("#mapel").text(data.mapel);
        $("#etanggal").val(data.tanggal);
        $("#eddlKelas").val(data.id_kelas).find("option[value=" + data.id_kelas +"]").attr('selected', true);
        $("#eddlMapel").val(data.id_gurumapel).find("option[value=" + data.id_gurumapel +"]").attr('selected', true);
        $("#eddlTahunAjaran").val(data.tahun_ajaran).find("option[value=' + data.tahun_ajaran +']").attr('selected', true);
        $("#eddlSemester").val(data.semester).find("option[value=' + data.semester +']").attr('selected', true);
      }else{
        swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
      }
    }
  });
}

function eSikap(kd_sikap){
  $('#elistsiswa tbody tr').remove();
  $.ajax({
    type: 'POST',
    url: '<?php echo e(url("eSikap")); ?>',
    data: {
      'kd_sikap': kd_sikap,
      "_token" : "<?php echo e(csrf_token()); ?>"
    },
    dataType: 'json',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal Menampilkan !", "Mohon Coba Lagi", "error");
    },
    success: function (data) {
      if (data != 'fail') {
        console.log(data);
        var tbl = '';
        for (var i = 0; i < data.length; i++) {
          var id = data[i].id_sikap_detail;
          var nama = data[i].nama_siswa;
          var status = data[i].status;
          var no = i + 1;
          tbl += '<tr>';
          tbl += '<td>' + no + '</td>';
          tbl += '<td style="display: none"><input type="text" name="id_detail[]" value="' + data[i].id_sikap_detail + '" hidden></td>';
          tbl += '<td><input type="text" class="form-control" name="nama_siswa[]" value="' + data[i].nama_siswa + '" style="background-color: #f7fafc; border: none" readonly></td>';
          tbl += '<td><input type="text" class="form-control" name="a1_kinerja1[]" value="'+data[i].a1_kinerja1+'"></td><td><input type="text" class="form-control" name="a1_kjinerja2[]" value="'+data[i].a1_kjinerja2+'"></td><td><input type="text" class="form-control" name="a1_portofolio[]" value="'+data[i].a1_portofolio+'"></td><td><input type="text" class="form-control" name="a1_optimum[]" value="'+data[i].a1_optimum+'"></td><td><input type="text" class="form-control" name="a1_remidi[]" value="'+data[i].a1_remidi+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="a2_kinerja1[]" value="'+data[i].a2_kinerja1+'"></td><td><input type="text" class="form-control" name="a2_kjinerja2[]" value="'+data[i].a2_kjinerja2+'"></td><td><input type="text" class="form-control" name="a2_portofolio[]" value="'+data[i].a2_portofolio+'"></td><td><input type="text" class="form-control" name="a2_optimum[]" value="'+data[i].a2_optimum+'"></td><td><input type="text" class="form-control" name="a2_remidi[]" value="'+data[i].a2_remidi+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="a3_kinerja1[]" value="'+data[i].a3_kinerja1+'"></td><td><input type="text" class="form-control" name="a3_kjinerja2[]" value="'+data[i].a3_kjinerja2+'"></td><td><input type="text" class="form-control" name="a3_portofolio[]" value="'+data[i].a3_portofolio+'"></td><td><input type="text" class="form-control" name="a3_optimum[]" value="'+data[i].a3_optimum+'"></td><td><input type="text" class="form-control" name="a3_remidi[]" value="'+data[i].a3_remidi+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="j_obs1[]" value="'+data[i].j_obs1+'"></td><td><input type="text" class="form-control" name="j_obs2[]" value="'+data[i].j_obs2+'"></td><td><input type="text" class="form-control" name="j_pd[]" value="'+data[i].j_pd+'"></td><td><input type="text" class="form-control" name="j_antarteman[]" value="'+data[i].j_antarteman+'"></td><td><input type="text" class="form-control" name="j_jurnal_guru[]" value="'+data[i].j_jurnal_guru+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="d_obs1[]" value="'+data[i].d_obs1+'"></td><td><input type="text" class="form-control" name="d_obs2[]" value="'+data[i].d_obs2+'"></td><td><input type="text" class="form-control" name="d_pd[]" value="'+data[i].d_pd+'"></td><td><input type="text" class="form-control" name="d_antarteman[]" value="'+data[i].d_antarteman+'"></td><td><input type="text" class="form-control" name="d_jurnal_guru[]" value="'+data[i].d_jurnal_guru+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="t_obs1[]" value="'+data[i].t_obs1+'"></td><td><input type="text" class="form-control" name="t_obs2[]" value="'+data[i].t_obs2+'"></td><td><input type="text" class="form-control" name="t_pd[]" value="'+data[i].t_pd+'"></td><td><input type="text" class="form-control" name="t_antarteman[]" value="'+data[i].t_antarteman+'"></td><td><input type="text" class="form-control" name="t_jurnal_guru[]" value="'+data[i].t_jurnal_guru+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="p_obs1[]" value="'+data[i].p_obs1+'"></td><td><input type="text" class="form-control" name="p_obs2[]" value="'+data[i].p_obs2+'"></td><td><input type="text" class="form-control" name="p_pd[]" value="'+data[i].p_pd+'"></td><td><input type="text" class="form-control" name="p_antarteman[]" value="'+data[i].p_antarteman+'"></td><td><input type="text" class="form-control" name="p_jurnal_guru[]" value="'+data[i].p_jurnal_guru+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="k_obs1[]" value="'+data[i].k_obs1+'"></td><td><input type="text" class="form-control" name="k_obs2[]" value="'+data[i].k_obs2+'"></td><td><input type="text" class="form-control" name="k_pd[]" value="'+data[i].k_pd+'"></td><td><input type="text" class="form-control" name="k_antarteman[]" value="'+data[i].k_antarteman+'"></td><td><input type="text" class="form-control" name="k_jurnal_guru[]" value="'+data[i].k_jurnal_guru+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="s_obs1[]" value="'+data[i].s_obs1+'"></td><td><input type="text" class="form-control" name="s_obs2[]" value="'+data[i].s_obs2+'"></td><td><input type="text" class="form-control" name="s_pd[]" value="'+data[i].s_pd+'"></td><td><input type="text" class="form-control" name="s_antarteman[]" value="'+data[i].s_antarteman+'"></td><td><input type="text" class="form-control" name="s_jurnal_guru[]" value="'+data[i].s_jurnal_guru+'"></td>';
          tbl += '<td><input type="text" class="form-control" name="nilai_sikap[]" value="'+data[i].nilai_sikap+'"></td><td><input type="text" class="form-control" name="predikat[]" value="'+data[i].predikat+'"></td>';
          tbl += '</tr>';
        }
        $('#elistsiswa tbody').append(tbl);
      }
    }
  });
}

$('#updateSikap').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
    url: '<?php echo e(url("updateSikap")); ?>',
    method: 'POST',
    data: form_data,
    dataType: 'JSON',
    error: function (xhr, ajaxOptions, thrownError) {
      swal("Gagal !", "Data Gagal Diubah !", "error");
    },
    success:function(data)
    {
      if (data == 'success') {
        swal("Berhasil !", "Data Berhasil Diubah !", "success");
        setTimeout(function(){
          window.location.reload();
        }, 1000);
      }else{
        swal("Gagal !", "Data Gagal Diubah !", "error");
      }
    }
  })
});

function deleteSikap(id){
  swal({
    title: "Apa Data Ingin Dihapus?",
    text: "Jika dihapus data tidak bisa dikembalikan lagi!",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  })
  .then((willDelete) => {
    if (willDelete) {
      $.ajax({
        url: '<?php echo e(url("deleteSikap")); ?>',
        type: 'POST',
        data: {
          "id" : id,
          "_token" : "<?php echo e(csrf_token()); ?>",
        },
        dataType: "HTML",
        error: function (xhr, ajaxOptions, thrownError) {
          swal("Gagal Menghapus !", "Mohon Coba Lagi", "error");
        },
        success: function(data) {
          if (data == 'success') {
            swal("Berhasil !", "Data Berhasil Dihapus !", "success");
            setTimeout(function(){
              window.location.reload();
            }, 1000);
          }else{
            swal("Gagal !", "Data Gagal Dihapus !", "danger");
          }
        }
      });
    } else {
    }
  });
} 
</script>