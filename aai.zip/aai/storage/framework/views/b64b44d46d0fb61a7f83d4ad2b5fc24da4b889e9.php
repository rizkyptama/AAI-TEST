<!-- Sidenav -->
  <nav class="sidenav navbar navbar-vertical fixed-left navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
      <!-- Brand -->
      <div class="sidenav-header d-flex align-items-center">
        <a class="navbar-brand" href="javascript:;">
          <img src="<?php echo e(asset('img/brand/blue.png')); ?>" class="navbar-brand-img" alt="...">
        </a>
        <div class="ml-auto">
          <!-- Sidenav toggler -->
          <div class="sidenav-toggler d-none d-xl-block" data-action="sidenav-unpin" data-target="#sidenav-main">
            <div class="sidenav-toggler-inner">
              <i class="sidenav-toggler-line"></i>
              <i class="sidenav-toggler-line"></i>
              <i class="sidenav-toggler-line"></i>
            </div>
          </div>
        </div>
      </div>
      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->
          <ul class="navbar-nav">
            <!-- <li class="nav-item <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>">
              <a class="nav-link <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>" href="<?php echo e(url('dashboard')); ?>">
                <i class="fa fa-home text-warning"></i>
                <span class="nav-link-text">Dashboard</span>
              </a>
            </li> -->
            <li class="nav-item <?php echo e(Request::is('jurnal') ? 'active' : ''); ?>">
              <a class="nav-link <?php echo e(Request::is('jurnal') ? 'active' : ''); ?>" href="<?php echo e(url('jurnal')); ?>">
                <i class="ni ni-book-bookmark text-success"></i>
                <span class="nav-link-text">Jurnal</span>
              </a>
            </li>
            <li class="nav-item <?php echo e(Request::is('kehadiran') ? 'active' : ''); ?>">
              <a class="nav-link <?php echo e(Request::is('kehadiran') ? 'active' : ''); ?>" href="<?php echo e(url('kehadiran')); ?>">
                <i class="ni ni-bullet-list-67 text-info"></i>
                <span class="nav-link-text">Kehadiran Siswa</span>
              </a>
            </li>
            <li class="nav-item <?php if(Request::is('pengetahuan') || Request::is('keterampilan') ||Request::is('sikap')){ ?>active<?php } ?>">
              <a class="<?php if(Request::is('pengetahuan') || Request::is('keterampilan') ||Request::is('sikap')){ ?> nav-link <?php }else{ ?> nav-link collapsed <?php } ?>" href="#penilaian" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="penilaian">
                <i class="ni ni-ruler-pencil text-danger"></i>
                <span class="nav-link-text">Penilaian</span>
              </a>
              <div class="<?php if(Request::is('pengetahuan') || Request::is('keterampilan') ||Request::is('sikap')){ ?> collapse show <?php }else{ ?> collapse <?php } ?>" id="penilaian">
                <ul class="nav nav-sm flex-column">
                  <li class="nav-item <?php echo e(Request::is('pengetahuan') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('pengetahuan')); ?>" class="nav-link <?php echo e(Request::is('pengetahuan') ? 'active' : ''); ?>">
                      <i class="ni ni-curved-next text-default"></i>
                      <span class="nav-link-text">Penilaian Pengetahuan</span>
                    </a>
                  </li>
                  <li class="nav-item <?php echo e(Request::is('keterampilan') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('keterampilan')); ?>" class="nav-link <?php echo e(Request::is('keterampilan') ? 'active' : ''); ?>">
                      <i class="ni ni-curved-next text-default"></i>
                      <span class="nav-link-text">Penilaian Keterampilan</span>
                    </a>
                  </li>
                  <li class="nav-item <?php echo e(Request::is('sikap') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('sikap')); ?>" class="nav-link <?php echo e(Request::is('sikap') ? 'active' : ''); ?>">
                      <i class="ni ni-curved-next text-default"></i>
                      <span class="nav-link-text">Penilaian Sikap</span>
                    </a>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
          <hr class="my-3">
        <!-- Heading -->
        <h6 class="navbar-heading p-0 text-muted">Other</h6>
        <!-- Navigation -->
        <ul class="navbar-nav mb-md-3">
          <li class="nav-item">
            <a class="nav-link" href="#" onclick="logout()">
              <i class="ni ni-user-run"></i>
              <span class="nav-link-text">Logout</span>
            </a>
          </li>
        </ul>
        </div>
      </div>
    </div>
  </nav>