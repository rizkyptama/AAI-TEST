<?php $__env->startSection('content'); ?>	

<!-- <div class="row">
	<div class="col-xl-5 col-5 col-md-5">
        <div class="card card-stats">
          	<div class="card-body">
            	<div class="row">
              		<div class="col">
		                <select class="form-control" id="ddlKelas" style="width:100%;" name="ddlKelas">
		                	<option value="" hidden=""></option>
		                	<?php foreach($kelas as $res): ?> 
		                	<option value="<?php echo e($res->id_kelas); ?>"><?php echo e($res->kelas); ?></option>
		                	<?php endforeach; ?>
		                </select>
             		</div>
             		<div class="col-auto">
               			<div class="icon icon-shape bg-gradient-orange text-white rounded-circle shadow">
                        	<i class="ni ni-shop"></i>
                      	</div>
                    </div>
            	</div>
         	</div>
     	</div>
  	</div>
  	<div class="col-xl-5 col-5 col-md-5">
    	<div class="card card-stats">
        	<div class="card-body">
           		<div class="row">
             		<div class="col">
                      	<select class="form-control" id="ddlMapel" style="width:100%;" name="ddlMapel">
		                	<option value="" hidden=""></option>
		                	<?php foreach($mapel as $res): ?> 
		                	<option value="<?php echo e($res->id_gurumapel); ?>"><?php echo e($res->mapel); ?></option>
		                	<?php endforeach; ?>
		                </select>
                    </div>
                    <div class="col-auto">
                    	<div class="icon icon-shape bg-gradient-green text-white rounded-circle shadow">
                        	<i class="ni ni-books"></i>
                      	</div>
                    </div>
             	</div>
         	</div>
      	</div>
  	</div>
  	<div class="col-xl-2 col-2 col-md-2">
    	<div class="card card-stats">
       		<button class="btn btn-secondary" style="height: 80px !important;" onclick="filterabsen()">
        		<div class="card-body">
           			<h1>Cari <i class="fa fa-search"></i></h1>
         		</div>
         	</button>
      	</div>
  	</div>
</div> -->

<div class="row">
	<div class="col-xl-12">
		<div class="card">
			<div class="card-header border-0">
				<div class="row align-items-center">
					<div class="col">
						<h3 class="mb-0">Halaman Jurnal</h3>
					</div>
					<div class="col text-right">
						<a href="#" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#ModalTambahJurnal"><i class="fas fa-plus text-white mr-1"></i> Jurnal</a>
					</div>
				</div>
			</div>
			<div class="table-responsive">
				<!-- Projects table -->
				<table class="table table-bordered align-items-center table-striped table-hover table-flush text-center datatables-print" id="tblJurnal">
					<thead class="thead-light">
						<tr>
							<th>No</th>
							<th>Mata Pelajaran</th>
							<th>Materi</th>
							<th>Tahun Ajaran</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody class="list">
						<?php $no = 1; ?>
						<?php foreach($jurnal as $row): ?>
						<tr>
							<th><?php echo e($no++); ?></th>
							<td><?php echo e($row->mapel); ?></td>
							<td><?php echo e($row->materi); ?></td>
							<td><?php echo e($row->tahun_ajaran); ?></td>
							<td>
								<button class="btn btn-warning btn-sm" type="button" onclick="editJurnal('<?php echo e($row->id_jurnal); ?>')" title="Ubah Data"><i class="fa fa-edit"></i></button>
								<button class="btn btn-danger btn-sm" type="button" onclick="deleteJurnal('<?php echo e($row->id_jurnal); ?>')" title="Hapus Data"><i class="fa fa-trash"></i></button>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>

<!-- The Modal Tambah-->
<div class="modal modal-secondary fade bd-example-modal-lg" id="ModalTambahJurnal">
  	<div class="modal-dialog modal-dialog-centered modal-lg">
    	<div class="modal-content">

	    	<!-- Modal Header -->
	    	<div class="modal-header">
	      		<h4 class="modal-title">Tambah Data Jurnal</h4>
	      		<button type="button" class="close" data-dismiss="modal">&times;</button>
	    	</div>

		    <!-- Modal body -->
		    <div class="modal-body">
		      	<div class="row">
			        <div class="col-lg-6">
			          <div class="form-group">
			            <label>Tanggal</label>
			            <input type="date" name="tanggal" value="<?php echo date('Y-m-d'); ?>" class="form-control" required="" id="tanggalJurnal">
			          </div>
			        </div>
			        <div class="col-lg-6">
			          	<div class="form-group">
				            <label>Kelas</label>
				            <select class="form-control" id="ddlKelas" style="width:100%;" name="ddlKelas">
			                	<option value="" hidden="">Pilih Kelas</option>
			                	<?php foreach($kelas as $res): ?> 
			                	<option value="<?php echo e($res->id_kelas); ?>"><?php echo e($res->tingkat_kelas); ?> <?php echo e($res->kelas); ?></option>
			                	<?php endforeach; ?>
			                </select>
			          	</div>
			        </div>
			        <div class="col-lg-6">
			          	<div class="form-group">
				            <label>Mata Pelajaran</label>
				            <select class="form-control" id="ddlJurnalMapel" style="width:100%;" name="ddlJurnalMapel">
			                	<option value="" hidden="">Pilih Mapel</option>
			                	<?php foreach($mapel as $res): ?> 
			                	<option value="<?php echo e($res->id_gurumapel); ?>"><?php echo e($res->mapel); ?></option>
			                	<?php endforeach; ?>
			                </select>
		            	</div>
			        </div>			        
			        <div class="col-lg-6">
			          	<div class="form-group">
			            	<label>Materi</label>
			            	<input type="text" name="materi" id="materi" class="form-control">
			          	</div>
			        </div>
			        <div class="col-lg-6">
			         	<div class="form-group">
			            	<label>Kompetensi</label>
				            <input type="text" name="kompetensi" id="kompetensi" class="form-control">
			          	</div>
			        </div>
			        <div class="col-lg-6">
			          	<div class="form-group">
			            	<label>Pertemuan ke-</label>
			            	<input type="number" name="pertemuan" id="pertemuan" class="form-control">
			          	</div>
			        </div>
			        <div class="col-lg-12">
			          <div class="form-group">
			            <label>Keterangan</label>
			            <textarea name="keterangan" id="keterangan" class="form-control" rows="4"></textarea>
			          </div>
			        </div>
			    </div>
	      	</div>
	      	<!-- Modal footer -->
	      	<div class="modal-footer">
	        	<button type="button" class="btn btn-lin mr-auto" data-dismiss="modal">Tutup</button>
	        	<button type="button" class="btn btn-info" onclick="tambahJurnal()">Simpan</button>
	      	</div>
    	</div>
  	</div>
</div>

<!-- The Modal Update-->
<div class="modal modal-secondary fade bd-example-modal-lg" id="ModalEditJurnal">
  	<div class="modal-dialog modal-dialog-centered modal-lg">
    	<div class="modal-content">

	    	<!-- Modal Header -->
	    	<div class="modal-header">
	      		<h4 class="modal-title">Ubah Data Jurnal</h4>
	      		<button type="button" class="close" data-dismiss="modal">&times;</button>
	    	</div>

		    <!-- Modal body -->
		    <div class="modal-body">
		      	<div class="row">
					<input type="hidden" name="id_jurnal" id="id_jurnal">
			        <div class="col-lg-6">
			          <div class="form-group">
			            <label>Tanggal</label>
			            <input type="date" name="tanggal" value="<?php echo date('Y-m-d'); ?>" class="form-control" required="" id="etanggalJurnal">
			          </div>
			        </div>
			        <div class="col-lg-6">
			          	<div class="form-group">
				            <label>Kelas</label>
				            <select class="form-control" id="eddlKelas" style="width:100%;" name="ddlKelas">
			                	<option value="" hidden="">Pilih Kelas</option>
			                	<?php foreach($kelas as $res): ?> 
			                	<option value="<?php echo e($res->id_kelas); ?>"><?php echo e($res->tingkat_kelas); ?> <?php echo e($res->kelas); ?></option>
			                	<?php endforeach; ?>
			                </select>
			          	</div>
			        </div>
			        <div class="col-lg-6">
			          	<div class="form-group">
				            <label>Mata Pelajaran</label>
				            <select class="form-control" id="eddlJurnalMapel" style="width:100%;" name="ddlJurnalMapel">
			                	<option value="" hidden="">Pilih Mapel</option>
			                	<?php foreach($mapel as $res): ?> 
			                	<option value="<?php echo e($res->id_gurumapel); ?>"><?php echo e($res->mapel); ?></option>
			                	<?php endforeach; ?>
			                </select>
		            	</div>
			        </div>			        
			        <div class="col-lg-6">
			          	<div class="form-group">
			            	<label>Materi</label>
			            	<input type="text" name="materi" id="emateri" class="form-control">
			          	</div>
			        </div>
			        <div class="col-lg-6">
			         	<div class="form-group">
			            	<label>Kompetensi</label>
				            <input type="text" name="kompetensi" id="ekompetensi" class="form-control">
			          	</div>
			        </div>
			        <div class="col-lg-6">
			          	<div class="form-group">
			            	<label>Pertemuan ke-</label>
			            	<input type="number" name="pertemuan" id="epertemuan" class="form-control">
			          	</div>
			        </div>
			        <div class="col-lg-12">
			          <div class="form-group">
			            <label>Keterangan</label>
			            <textarea name="keterangan" id="eketerangan" class="form-control" rows="4"></textarea>
			          </div>
			        </div>
			    </div>
	      	</div>
	      	<!-- Modal footer -->
	      	<div class="modal-footer">
	        	<button type="button" class="btn btn-lin mr-auto" data-dismiss="modal">Tutup</button>
	        	<button type="button" class="btn btn-info" onclick="updateJurnal()">Update</button>
	      	</div>
    	</div>
  	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>